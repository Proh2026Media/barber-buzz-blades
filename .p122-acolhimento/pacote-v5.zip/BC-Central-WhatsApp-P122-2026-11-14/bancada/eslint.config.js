import js from "@eslint/js";
import eslintPluginPrettier from "eslint-plugin-prettier/recommended";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import tseslint from "typescript-eslint";

export default tseslint.config(
  {
    ignores: [
      "**/._*",
      ".fotos/**",
      ".kilo/**",
      ".nitro",
      ".output",
      ".tanstack",
      ".vinxi",
      ".wrangler",
      "dist",
      "scratch/**",
      "supabase/.temp",
    ],
  },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "server-only",
              message:
                "TanStack Start does not use the Next.js `server-only` package. Rename the module to `*.server.ts` or mark it with `@tanstack/react-start/server-only`.",
            },
          ],
        },
      ],
      "react-refresh/only-export-components": ["warn", { allowConstantExport: true }],
      "@typescript-eslint/no-unused-vars": "off",
    },
  },
  eslintPluginPrettier,
  {
    // Componentes base (shadcn): exportam as variantes de estilo junto do componente.
    files: ["src/components/ui/**/*.tsx"],
    rules: { "react-refresh/only-export-components": "off" },
  },
  {
    // The MCP Vite plugin regenerates these files on every dev/build startup.
    // Keep semantic lint checks; formatting belongs to the generator.
    files: [
      "src/routes/mcp.ts",
      "src/routes/\\[.mcp\\]/**/*.ts",
      "src/routes/\\[.well-known\\]/oauth-protected-resource.ts",
    ],
    rules: { "prettier/prettier": "off" },
  },
);
