import type { PrivacyRequest } from "../insights/DataRights";
import { validateOccurrence, type Occurrence } from "../insights/occurrences.ts";
import { defaultPrivacy, type PrivacyPreferences, type Survey } from "../insights/model.ts";
import type { Tables } from "@/integrations/supabase/types";
import {
  advanceWaits,
  disableWaits,
  withdrawDemo,
  waitingDemoAction,
  type DemoWait,
} from "../waiting/demo.ts";
import { blocksSlot, type WaitAction, type WaitingEvent } from "../waiting/model.ts";
import type { LoyaltyReward } from "../loyalty/program.ts";
import { DEMO_ASSOCIATE_STAFF_ID, DEMO_EMPLOYEE_STAFF_ID } from "./team.ts";
import { demoServiceTerms } from "./catalog.ts";

export const DEMO_CUSTOMER_ID = "demo-customer";

export type DemoRedemption = {
  id: string;
  reward_id: string;
  reward_name: string;
  cost_points: number;
  status: "pending" | "cancelled";
  created_at: string;
  expires_at: string;
};

export const DEMO_REWARDS: LoyaltyReward[] = [
  {
    id: "demo-reward-beard",
    name: "Barba grátis",
    description: "Uma barba completa por conta da casa.",
    cost_points: 150,
    active: true,
    sort_order: 0,
  },
  {
    id: "demo-reward-cut",
    name: "Corte grátis",
    description: "Um corte de cabelo por conta da casa.",
    cost_points: 400,
    active: true,
    sort_order: 1,
  },
];

/** Total ganho na vida: saldo atual mais o que está reservado em resgates. */
export function demoLifetimePoints(state: Pick<DemoState, "points" | "redemptions">) {
  return (
    state.points +
    state.redemptions
      .filter((row) => row.status === "pending")
      .reduce((sum, row) => sum + row.cost_points, 0)
  );
}

/**
 * Ficha da equipe (migration 20261016130000): cliente do balcão (sem conta, com nome e WhatsApp
 * informados pelo barbeiro) ou só o apelido de um cliente com conta (`profile_id`).
 */
export type DemoShopClient = {
  id: string;
  profile_id: string | null;
  full_name: string | null;
  whatsapp_e164: string | null;
  nickname: string | null;
  notify_whatsapp: boolean;
};

/** Horário recorrente ativo (só para os selos da agenda e da ficha). */
export type DemoSeries = {
  id: string;
  customer_id: string;
  kind: "weekday" | "interval_days";
  interval_days: number | null;
  active: boolean;
};

export type DemoState = {
  waits: DemoWait[];
  waitingEvents: WaitingEvent[];
  settings: Tables<"barbershop_settings">;
  cancellationReasons: Record<string, { reason: string | null; source: "customer" | "shop" }>;
  attendance: Record<string, Occurrence>;
  prices: Record<string, number>;
  privacy: PrivacyPreferences;
  surveys: Survey[];
  lastSurveyAt: string | null;
  privacyRequests: PrivacyRequest[];
  now: Date;
  /** Clientes com conta (fictícios). O WhatsApp serve para a busca do "Agendar cliente". */
  customers: { id: string; name: string; whatsapp: string | null }[];
  customerId: string;
  shopClients: DemoShopClient[];
  series: DemoSeries[];
  shop: Tables<"barbershops">;
  services: Tables<"services">[];
  staff: Tables<"staff">[];
  appointments: Tables<"appointments">[];
  businessHours: Tables<"business_hours">[];
  availabilityBlocks: Tables<"availability_blocks">[];
  /** Catálogo próprio de cada profissional (o Parceiro personaliza preço e duração). */
  staffServices: Tables<"staff_services">[];
  /** Sugestões fictícias de catálogo que o Parceiro já decidiu (usar ou manter a dele). */
  decidedSuggestions: string[];
  customerName: string;
  points: number;
  awarded: string[];
  redemptions: DemoRedemption[];
};

export type DemoShopPreset = {
  shop: Tables<"barbershops">;
  settings: Tables<"barbershop_settings">;
  services: Tables<"services">[];
  staff: Tables<"staff">[];
  businessHours: Tables<"business_hours">[];
};

/**
 * Fuso do aparelho. A demonstração monta as datas no relógio local; mostrar a agenda
 * nesse mesmo fuso evita que um visitante fora de Brasília veja tudo deslocado.
 */
function deviceTimeZone() {
  try {
    const zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (zone) {
      new Intl.DateTimeFormat("en-US", { timeZone: zone });
      return zone;
    }
  } catch {
    // Fuso desconhecido: mantém o padrão abaixo.
  }
  return "America/Sao_Paulo";
}

/** Horas inteiras de atendimento do dia, conforme o expediente da loja (padrão 9h às 19h). */
function openHoursFor(rows: Tables<"business_hours">[], weekday: number) {
  if (!rows.length) return weekday === 0 ? [] : range(9, 19);
  const row = rows.find((item) => item.weekday === weekday);
  if (!row || !row.is_open || !row.opens_at || !row.closes_at) return [];
  const [openH, openM] = row.opens_at.split(":").map(Number);
  const [closeH, closeM] = row.closes_at.split(":").map(Number);
  const first = (openH || 0) + ((openM || 0) > 0 ? 1 : 0);
  const close = (closeH || 0) + (closeM || 0) / 60;
  return range(first, Math.floor(close));
}

function range(from: number, to: number) {
  return Array.from({ length: Math.max(0, to - from) }, (_, index) => from + index);
}

/**
 * Exemplos da equipe na demonstração: apelidos (um deles no cliente nº 3, para testar a busca pelo
 * WhatsApp (11) 95550-0003), clientes com horário recorrente na agenda de hoje e um cliente do
 * balcão marcado pelo barbeiro no primeiro horário livre.
 */
function seedTeamClients(state: DemoState, stamp: string) {
  const owner = state.staff[0];
  const sameDay = (iso: string) => new Date(iso).toDateString() === state.now.toDateString();
  const todays = state.appointments
    .filter(
      (row) =>
        row.status === "confirmed" &&
        sameDay(row.starts_at) &&
        !!row.customer_id &&
        row.customer_id !== DEMO_CUSTOMER_ID,
    )
    .sort((a, b) => a.starts_at.localeCompare(b.starts_at));
  const ownerToday = todays.filter((row) => row.staff_id === owner?.id);
  const otherToday = todays.filter((row) => row.staff_id !== owner?.id);

  const nickname = (customerId: string | null | undefined, value: string) => {
    if (!customerId || state.shopClients.some((row) => row.profile_id === customerId)) return;
    state.shopClients.push({
      id: `demo-client-nick-${customerId}`,
      profile_id: customerId,
      full_name: null,
      whatsapp_e164: null,
      nickname: value,
      notify_whatsapp: true,
    });
  };
  nickname(state.customers[3]?.id, "Alemão");
  nickname(ownerToday[2]?.customer_id, "Magrão");
  nickname(otherToday[1]?.customer_id, "Professor");

  const series = (
    row: Tables<"appointments"> | undefined,
    kind: DemoSeries["kind"],
    interval: number | null,
  ) => {
    if (!row?.customer_id) return;
    const id = `demo-series-${row.id}`;
    state.series.push({
      id,
      customer_id: row.customer_id,
      kind,
      interval_days: interval,
      active: true,
    });
    row.series_id = id;
  };
  series(ownerToday[1], "weekday", null);
  series(ownerToday[3], "interval_days", 15);
  series(otherToday[0], "weekday", null);

  // Cliente do balcão: o barbeiro marcou pelo painel; não tem conta nem horário recorrente.
  const service = state.services[0];
  if (owner && service) {
    const start = firstFreeStart(state, owner.id, service.duration_minutes);
    if (start) {
      state.shopClients.push({
        id: "demo-client-walkin",
        profile_id: null,
        full_name: "Zé da Padaria",
        whatsapp_e164: "+5511955599999",
        nickname: "Zé",
        notify_whatsapp: true,
      });
      state.appointments.push({
        id: "demo-walkin-today",
        barbershop_id: state.shop.id,
        customer_id: null,
        shop_client_id: "demo-client-walkin",
        booked_by: "demo-admin",
        service_id: service.id,
        staff_id: owner.id,
        starts_at: start.toISOString(),
        ends_at: new Date(start.getTime() + service.duration_minutes * 60000).toISOString(),
        status: "confirmed",
        booked_price_cents: service.price_cents,
        public_token: "demo-token-walkin",
        series_id: null,
        created_at: stamp,
        updated_at: stamp,
      });
    }
  }
}

/**
 * Primeiro início livre (de meia em meia hora) para o profissional: hoje depois da hora atual, ou
 * no próximo dia aberto, sempre dentro do expediente da loja (domingo fechado continua fechado).
 */
function firstFreeStart(state: DemoState, staffId: string, minutes: number): Date | null {
  for (let offset = 0; offset < 7; offset++) {
    const day = new Date(state.now);
    day.setDate(day.getDate() + offset);
    const hours = openHoursFor(state.businessHours, day.getDay());
    if (!hours.length) continue;
    const closing = (hours.at(-1) ?? 0) + 1;
    for (const hour of hours) {
      for (const minute of [0, 30]) {
        const start = new Date(day);
        start.setHours(hour, minute, 0, 0);
        if (start.getTime() <= state.now.getTime()) continue;
        const end = new Date(start.getTime() + minutes * 60000);
        if (end.getHours() + end.getMinutes() / 60 > closing) continue;
        const busy = state.appointments.some(
          (row) =>
            row.staff_id === staffId &&
            row.status !== "cancelled" &&
            Date.parse(row.starts_at) < end.getTime() &&
            Date.parse(row.ends_at) > start.getTime(),
        );
        if (!busy) return start;
      }
    }
  }
  return null;
}

export function createDemoState(date = new Date(), preset?: DemoShopPreset): DemoState {
  const now = new Date(date);
  now.setHours(9, 0, 0, 0);
  const stamp = now.toISOString();
  const shopId = "demo-shop";
  const common = {
    barbershop_id: shopId,
    active: true,
    description: null,
    created_at: stamp,
    updated_at: stamp,
  };
  const time = (hour: number, minute = 0) => {
    const value = new Date(now);
    if (value.getDay() === 0) value.setDate(value.getDate() + 1);
    value.setHours(hour, minute, 0, 0);
    return value.toISOString();
  };
  const firstNames = [
    "Rafael",
    "Lucas",
    "Pedro",
    "Miguel",
    "Arthur",
    "Gabriel",
    "João",
    "Matheus",
    "Bruno",
    "Diego",
    "André",
    "Felipe",
    "Daniel",
    "Caio",
    "Thiago",
    "Vitor",
    "Enzo",
    "Davi",
    "Gustavo",
    "Henrique",
  ];
  const surnames = [
    "Lima",
    "Santos",
    "Oliveira",
    "Costa",
    "Souza",
    "Almeida",
    "Ribeiro",
    "Martins",
    "Rocha",
    "Barbosa",
  ];
  const offset = Math.floor(Math.random() * 200);
  const customers = Array.from({ length: 200 }, (_, index) => {
    const variant = (index + offset) % 200;
    return {
      id:
        index === 0
          ? DEMO_CUSTOMER_ID
          : index === 1
            ? "demo-other-customer"
            : `demo-customer-${index}`,
      name: `${firstNames[variant % 20]} ${surnames[Math.floor(variant / 20)]} (demo)`,
      whatsapp: `+55119555${String(index).padStart(5, "0")}`,
    };
  });
  const state: DemoState = {
    waits: [],
    waitingEvents: [],
    settings: {
      barbershop_id: shopId,
      display_name: "Arena Barber",
      logo_url: null,
      logo_background_color: null,
      login_image_url: null,
      login_layout: "split",
      font_family: "inter",
      custom_font_url: null,
      custom_font_name: null,
      custom_font_faces: [],
      font_scope: "header",
      header_font_weight: 700,
      header_font_style: "normal",
      corner_style: "soft",
      floating_chrome: false,
      primary_color: "#292925",
      accent_color: "#8A602F",
      tagline: "Club & Lounge",
      booking_instructions: "Chegue 5 minutos antes para aproveitar seu atendimento com calma.",
      booking_horizon_days: 14,
      survey_program_enabled: true,
      sports_enabled: true,
      loyalty_enabled: true,
      landing: {},
      waiting_enabled: false,
      waiting_cutoff_minutes: 30,
      staff_assignment_mode: "client_pick",
      slot_mode: "flexible",
      slot_step_minutes: 15,
      prep_minutes: 0,
      min_lead_minutes: 30,
      created_at: stamp,
      updated_at: stamp,
    },
    cancellationReasons: {},
    attendance: {},
    prices: {},
    privacy: { ...defaultPrivacy },
    surveys: [],
    lastSurveyAt: null,
    privacyRequests: [
      {
        id: "demo-privacy-request",
        user_id: "demo-privacy-customer",
        status: "requested",
        created_at: stamp,
        updated_at: stamp,
      },
    ],
    now,
    customers,
    customerId: DEMO_CUSTOMER_ID,
    shopClients: [],
    series: [],
    shop: {
      id: shopId,
      name: "Arena Barber · Demo",
      slug: "arena-demo",
      status: "active",
      timezone: deviceTimeZone(),
      custom_domain: null,
      custom_domain_status: "none",
      domain_verify_token: null,
      domain_verified_at: null,
      domain_last_error: null,
      created_at: stamp,
      updated_at: stamp,
    },
    services: [
      {
        ...common,
        id: "demo-cut",
        name: "Corte Tradicional",
        duration_minutes: 30,
        price_cents: 4500,
        prep_minutes: null,
        icon: "Scissors",
      },
      {
        ...common,
        id: "demo-beard",
        name: "Barboterapia",
        duration_minutes: 45,
        price_cents: 6000,
        prep_minutes: null,
        icon: "Droplet",
      },
      {
        ...common,
        id: "demo-combo",
        name: "Combo Premium",
        duration_minutes: 60,
        price_cents: 9000,
        prep_minutes: null,
        icon: "Crown",
      },
      {
        ...common,
        id: "demo-finish",
        name: "Acabamento",
        duration_minutes: 15,
        price_cents: 2000,
        prep_minutes: null,
        icon: "Scissors",
      },
      {
        ...common,
        id: "demo-kids",
        name: "Corte infantil",
        duration_minutes: 30,
        price_cents: 3500,
        prep_minutes: null,
        icon: "Scissors",
      },
      {
        ...common,
        id: "demo-hydrate",
        name: "Hidratação",
        duration_minutes: 30,
        price_cents: 5000,
        prep_minutes: null,
        icon: "Scissors",
      },
      {
        ...common,
        id: "demo-style",
        name: "Penteado",
        duration_minutes: 30,
        price_cents: 4000,
        prep_minutes: null,
        icon: "Scissors",
      },
    ],
    staff: [
      {
        ...common,
        id: "demo-carlos",
        display_name: "Mestre Carlão",
        user_id: null,
        booking_slug: "carlao",
        bio: "Especialista em cortes clássicos e degradê. Mais de 15 anos de barbearia.",
        avatar_url: null,
      },
      {
        ...common,
        id: "demo-bruno",
        display_name: "Bruno Oliveira",
        user_id: null,
        booking_slug: "bruno",
        bio: "Focado em barboterapia e acabamento. Atendimento de precisão.",
        avatar_url: null,
      },
      ...["Dani Costa", "Pedro Alves", "Lu Martins"].map((display_name, index) => ({
        ...common,
        id: `demo-extra-staff-${index}`,
        display_name,
        user_id: null,
        booking_slug: `demo-profissional-${index}`,
        bio: "Profissional fictício da demonstração.",
        avatar_url: null,
      })),
    ],
    appointments: [
      {
        id: "demo-booking-1",
        barbershop_id: shopId,
        customer_id: DEMO_CUSTOMER_ID,
        service_id: "demo-cut",
        staff_id: "demo-carlos",
        starts_at: time(10),
        ends_at: time(10, 30),
        status: "confirmed",
        // O preço gravado é o do serviço (o mesmo que Agendar mostra).
        booked_price_cents: 4500,
        public_token: "demo-token-1",
        series_id: null,
        created_at: stamp,
        updated_at: stamp,
      },
      {
        id: "demo-booking-2",
        barbershop_id: shopId,
        customer_id: "demo-other-customer",
        service_id: "demo-combo",
        staff_id: "demo-bruno",
        starts_at: time(11),
        ends_at: time(12),
        status: "confirmed",
        booked_price_cents: 9000,
        public_token: "demo-token-2",
        series_id: null,
        created_at: stamp,
        updated_at: stamp,
      },
    ],
    businessHours: Array.from({ length: 7 }, (_, weekday) => ({
      id: `demo-hours-${weekday}`,
      barbershop_id: shopId,
      weekday,
      is_open: weekday !== 0,
      opens_at: "09:00:00",
      closes_at: "19:00:00",
      created_at: stamp,
      updated_at: stamp,
    })),
    availabilityBlocks: [],
    staffServices: [],
    decidedSuggestions: [],
    customerName: customers[0].name,
    points: 250,
    awarded: [],
    redemptions: [],
  };
  if (preset) {
    // "Testar como…" copia só a aparência e o catálogo da loja real. Todos os ids viram
    // fictícios (loja, equipe, serviços, horários) e nada aponta para a loja ou contas reais:
    // a demonstração nunca consegue ler nem gravar dados reais por engano.
    state.shop = {
      ...preset.shop,
      id: shopId,
      name: `${preset.shop.name} · Demo`,
      slug: state.shop.slug,
      status: "active",
      custom_domain: null,
      custom_domain_status: "none",
      domain_verify_token: null,
      domain_verified_at: null,
      domain_last_error: null,
      // As datas da demo são montadas no relógio do aparelho (ver deviceTimeZone).
      timezone: deviceTimeZone(),
    };
    state.settings = { ...preset.settings, barbershop_id: shopId, sports_enabled: true };
    if (preset.services.length) {
      state.services = preset.services.map((row, index) => ({
        ...row,
        id: `demo-service-${index + 1}`,
        barbershop_id: shopId,
      }));
    }
    if (preset.staff.length) {
      state.staff = preset.staff.map((row, index) => ({
        ...row,
        id: `demo-staff-${index + 1}`,
        barbershop_id: shopId,
        user_id: null,
      }));
    }
    if (preset.businessHours.length) {
      state.businessHours = preset.businessHours.map((row) => ({
        ...row,
        id: `demo-hours-${row.weekday}`,
        barbershop_id: shopId,
      }));
    }
    const firstService = state.services[0]!;
    const firstStaff = state.staff[0]!;
    state.appointments = state.appointments.map((row, index) => {
      const service = state.services[index % state.services.length] ?? firstService;
      return {
        ...row,
        barbershop_id: shopId,
        service_id: service.id,
        staff_id: state.staff[index % state.staff.length]?.id ?? firstStaff.id,
        // O preço gravado acompanha o serviço copiado da loja.
        booked_price_cents: service.price_cents,
      };
    });
  }
  // Personagens próprios do Parceiro e do Contratado (plano de ambientes, onda 5): cada papel da
  // demonstração tem o próprio cartão, a própria agenda e o próprio link, com ids fictícios.
  state.staff = [
    ...state.staff.filter(
      (row) => row.id !== DEMO_ASSOCIATE_STAFF_ID && row.id !== DEMO_EMPLOYEE_STAFF_ID,
    ),
    {
      ...common,
      id: DEMO_ASSOCIATE_STAFF_ID,
      display_name: "Rafa Lima",
      user_id: null,
      booking_slug: "rafa",
      bio: "Parceiro da casa: agenda, serviços e valores próprios.",
      avatar_url: null,
    },
    {
      ...common,
      id: DEMO_EMPLOYEE_STAFF_ID,
      display_name: "Léo Souza",
      user_id: null,
      booking_slug: "leo",
      bio: "Contratado: atende na agenda da casa.",
      avatar_url: null,
    },
  ];
  // A loja fictícia demonstra catálogo próprio. A prévia de uma loja real conserva o catálogo
  // copiado, sem inventar vínculos com profissionais cujos ids foram anonimizados.
  if (!preset) {
    state.staffServices = state.staff.flatMap((member) =>
      state.services.map((service) => ({
        id: `demo-own-${member.id}-${service.id}`,
        barbershop_id: state.shop.id,
        staff_id: member.id,
        service_id: service.id,
        display_name: null,
        icon: null,
        active: !(member.id === "demo-extra-staff-0" && service.id === "demo-beard"),
        duration_minutes:
          member.id === "demo-bruno" && service.id === "demo-cut"
            ? 45
            : member.id === DEMO_ASSOCIATE_STAFF_ID && service.id === "demo-beard"
              ? 30
              : service.duration_minutes,
        price_cents:
          member.id === "demo-bruno" && service.id === "demo-cut"
            ? 5500
            : member.id === DEMO_ASSOCIATE_STAFF_ID && service.id === "demo-beard"
              ? 6500
              : service.price_cents,
        created_at: stamp,
        updated_at: stamp,
      })),
    );
  }
  // A janela de 120 dias para trás garante visitas recorrentes suficientes para
  // o "ritmo" (frequência de retorno) ter dados na demonstração.
  // Cada horário tem 1 h: só sorteia serviços que cabem nele, para não invadir o seguinte.
  // Se nenhum serviço cabe em 1 h, usa o mais curto e alarga o horário para caber nele.
  const fittingServices = state.services.filter((service) => service.duration_minutes <= 60);
  const slotServices = fittingServices.length
    ? fittingServices
    : [
        state.services.reduce((short, service) =>
          service.duration_minutes < short.duration_minutes ? service : short,
        ),
      ];
  const slotHours = Math.max(
    1,
    ...slotServices.map((service) => Math.ceil(service.duration_minutes / 60)),
  );
  const pickService = (staffId: string) => {
    const choices = slotServices.flatMap((service) => {
      const terms = demoServiceTerms(state, staffId, service.id);
      return terms && terms.duration_minutes <= slotHours * 60 ? [{ ...service, ...terms }] : [];
    });
    return choices[Math.floor(Math.random() * choices.length)];
  };
  const slots: { start: Date; staffId: string }[] = [];
  for (let day = -120; day <= 13; day++) {
    const start = new Date(now);
    start.setDate(start.getDate() + day);
    const hours = openHoursFor(state.businessHours, start.getDay());
    for (let index = 0; index + slotHours <= hours.length; index += slotHours) {
      start.setHours(hours[index]!, 0, 0, 0);
      for (const member of state.staff) {
        if (
          state.appointments.some(
            (row) =>
              row.staff_id === member.id &&
              new Date(row.starts_at).getTime() < start.getTime() + slotHours * 3600000 &&
              new Date(row.ends_at) > start,
          )
        )
          continue;
        slots.push({ start: new Date(start), staffId: member.id });
      }
    }
  }

  // Agrupa os horários livres do PASSADO por dia para montar históricos com
  // intervalos realistas. Os horários futuros ficam em um pool separado, para
  // nunca haver sobreposição entre uma visita passada e uma reserva futura.
  const pastSlots = slots.filter((slot) => slot.start < now);
  const futureSlots = slots.filter((slot) => slot.start >= now);
  const slotsByDay = new Map<string, { start: Date; staffId: string }[]>();
  for (const slot of pastSlots) {
    const key = slot.start.toISOString().slice(0, 10);
    const list = slotsByDay.get(key);
    if (list) list.push(slot);
    else slotsByDay.set(key, [slot]);
  }
  const dayKeys = [...slotsByDay.keys()].sort();

  const claimSlotOn = (target: Date): { start: Date; staffId: string } | null => {
    const targetKey = target.toISOString().slice(0, 10);
    const direct = slotsByDay.get(targetKey);
    if (direct && direct.length) return direct.shift()!;
    const targetIndex = dayKeys.indexOf(targetKey);
    for (let distance = 1; distance < dayKeys.length; distance++) {
      for (const sign of [-1, 1]) {
        const key = dayKeys[targetIndex + sign * distance];
        const list = key ? slotsByDay.get(key) : undefined;
        if (list && list.length) return list.shift()!;
      }
    }
    return null;
  };

  // Cada cliente recebe um histórico de 4 a 6 visitas concluídas, com cadência
  // de retorno própria (10 a 25 dias), e uma reserva futura confirmada.
  let futureCursor = 0;
  customers.forEach((customer, index) => {
    const visitCount = 4 + (index % 3); // 4–6 visitas
    const intervalDays = 10 + (index % 16); // 10–25 dias entre visitas
    for (let visit = 0; visit < visitCount; visit++) {
      const date = new Date(now);
      date.setDate(date.getDate() - intervalDays * (visitCount - 1 - visit));
      if (date.getDay() === 0) date.setDate(date.getDate() + 1);
      const slot = claimSlotOn(date);
      if (!slot) continue;
      const service = pickService(slot.staffId);
      if (!service) continue;
      state.appointments.push({
        id: `demo-generated-${index}-${visit}`,
        barbershop_id: state.shop.id,
        customer_id: customer.id,
        service_id: service.id,
        staff_id: slot.staffId,
        starts_at: slot.start.toISOString(),
        ends_at: new Date(slot.start.getTime() + service.duration_minutes * 60000).toISOString(),
        status: "completed",
        booked_price_cents: service.price_cents,
        public_token: `demo-token-${index}-${visit}`,
        series_id: null,
        created_at: stamp,
        updated_at: stamp,
      });
    }
    // Sem reaproveitar horário: quando acabam os livres, o cliente fica sem reserva futura.
    const future = futureCursor < futureSlots.length ? futureSlots[futureCursor++] : undefined;
    if (future) {
      const service = pickService(future.staffId);
      if (!service) return;
      state.appointments.push({
        id: `demo-generated-${index}-upcoming`,
        barbershop_id: state.shop.id,
        customer_id: customer.id,
        service_id: service.id,
        staff_id: future.staffId,
        starts_at: future.start.toISOString(),
        ends_at: new Date(future.start.getTime() + service.duration_minutes * 60000).toISOString(),
        status: "confirmed",
        booked_price_cents: service.price_cents,
        public_token: `demo-token-${index}-upcoming`,
        series_id: null,
        created_at: stamp,
        updated_at: stamp,
      });
    }
  });
  seedTeamClients(state, stamp);
  state.prices = Object.fromEntries(
    state.appointments.map((row) => [
      row.id,
      row.booked_price_cents ??
        state.services.find((service) => service.id === row.service_id)!.price_cents,
    ]),
  );
  state.awarded = state.appointments
    .filter((row) => row.status === "completed")
    .map((row) => row.id);
  state.points +=
    state.appointments.filter(
      (row) => row.status === "completed" && row.customer_id === DEMO_CUSTOMER_ID,
    ).length * 50;
  return state;
}

export type DemoAction =
  | { type: "survey.record"; survey: Survey }
  | { type: "cancel"; id: string; reason: string | null; source: "customer" | "shop" }
  | { type: "privacy.request"; status: PrivacyRequest["status"]; id?: string }
  | { type: "attendance"; id: string; stage: "arrived_at" | "started_at" | "no_show_at" }
  | {
      type: "occurrence";
      id: string;
      customer: number | null;
      shop: number | null;
      noShow: boolean;
    }
  | { type: "privacy.save"; preferences: PrivacyPreferences }
  | { type: "privacy.erase" }
  | { type: "survey.show"; survey: Survey }
  | { type: "survey.answer"; id: string; answer: string | null }
  | { type: "staff.delete"; id: string }
  | { type: "service.delete"; id: string }
  | { type: "service.edit"; service: Tables<"services"> }
  | { type: "staff.edit"; staff: Tables<"staff"> }
  | { type: "profile.save"; name: string }
  | { type: "book"; appointment: Tables<"appointments"> }
  | {
      type: "reschedule";
      id: string;
      starts_at: string;
      ends_at: string;
      service_id: string;
      staff_id: string;
    }
  | { type: "status"; id: string; status: Tables<"appointments">["status"] }
  | { type: "service.add"; service: Tables<"services"> }
  | { type: "service.toggle"; id: string }
  | { type: "staff.add"; staff: Tables<"staff"> }
  | { type: "staff.toggle"; id: string }
  | { type: "hours.save"; hours: Tables<"business_hours">[] }
  | { type: "block.add"; block: Tables<"availability_blocks"> }
  | { type: "block.delete"; id: string }
  | { type: "staffService.save"; row: Tables<"staff_services"> }
  | { type: "suggestion.decide"; id: string }
  | { type: "settings.save"; settings: Tables<"barbershop_settings"> }
  | { type: "shop.update"; shop: Partial<Pick<Tables<"barbershops">, "name" | "status">> }
  | { type: "clock.advance"; milliseconds: number }
  | { type: "loyalty.redeem"; rewardId: string }
  | { type: "loyalty.cancel"; id: string }
  | { type: "waiting.action"; id: string; action: WaitAction; serviceId?: string }
  /** Agendar pelo painel (barbeiro): o atendimento e, se for o caso, a ficha nova ou atualizada. */
  | { type: "client.book"; appointment: Tables<"appointments">; client?: DemoShopClient }
  | {
      type: "client.nickname";
      customerId: string | null;
      shopClientId: string | null;
      nickname: string | null;
    }
  | {
      type: "client.update";
      id: string;
      full_name?: string;
      whatsapp_e164?: string;
      notify_whatsapp?: boolean;
    };

export function demoReducer(state: DemoState, action: DemoAction): DemoState {
  state = advanceWaits(state);
  switch (action.type) {
    case "clock.advance":
      return advanceWaits({ ...state, now: new Date(+state.now + action.milliseconds) });
    case "waiting.action":
      return waitingDemoAction(state, action.id, action.action, action.serviceId);
    case "loyalty.redeem": {
      const reward = DEMO_REWARDS.find((row) => row.id === action.rewardId && row.active);
      const pending = state.redemptions.filter((row) => row.status === "pending").length;
      if (!reward || state.points < reward.cost_points || pending >= 3) return state;
      return {
        ...state,
        points: state.points - reward.cost_points,
        redemptions: [
          {
            id: `demo-redemption-${state.redemptions.length + 1}`,
            reward_id: reward.id,
            reward_name: reward.name,
            cost_points: reward.cost_points,
            status: "pending",
            created_at: state.now.toISOString(),
            expires_at: new Date(+state.now + 30 * 86_400_000).toISOString(),
          },
          ...state.redemptions,
        ],
      };
    }
    case "loyalty.cancel": {
      const target = state.redemptions.find(
        (row) => row.id === action.id && row.status === "pending",
      );
      if (!target) return state;
      return {
        ...state,
        points: state.points + target.cost_points,
        redemptions: state.redemptions.map((row) =>
          row.id === target.id ? { ...row, status: "cancelled" } : row,
        ),
      };
    }
    case "client.book": {
      const terms = demoServiceTerms(
        state,
        action.appointment.staff_id,
        action.appointment.service_id,
      );
      if (!terms) return state;
      const appointment = {
        ...action.appointment,
        ends_at: new Date(
          Date.parse(action.appointment.starts_at) + terms.duration_minutes * 60000,
        ).toISOString(),
        booked_price_cents: terms.price_cents,
      };
      const clash = state.appointments.some(
        (row) =>
          row.staff_id === appointment.staff_id &&
          (row.status === "pending" || row.status === "confirmed") &&
          row.starts_at < appointment.ends_at &&
          row.ends_at > appointment.starts_at,
      );
      const held = state.waits.some(
        (w) =>
          blocksSlot(w, state.now) &&
          w.staff_id === appointment.staff_id &&
          w.starts_at < appointment.ends_at &&
          w.ends_at > appointment.starts_at,
      );
      if (clash || held) return state;
      const client = action.client;
      return {
        ...state,
        shopClients: client
          ? [...state.shopClients.filter((row) => row.id !== client.id), client]
          : state.shopClients,
        prices: {
          ...state.prices,
          [appointment.id]: appointment.booked_price_cents,
        },
        appointments: [...state.appointments, { ...appointment, status: "confirmed" }],
      };
    }
    case "client.nickname": {
      const existing = state.shopClients.find((row) =>
        action.shopClientId
          ? row.id === action.shopClientId
          : !!action.customerId && row.profile_id === action.customerId,
      );
      if (existing) {
        return {
          ...state,
          shopClients: state.shopClients.map((row) =>
            row.id === existing.id ? { ...row, nickname: action.nickname } : row,
          ),
        };
      }
      if (!action.customerId) return state;
      return {
        ...state,
        shopClients: [
          ...state.shopClients,
          {
            id: `demo-client-${action.customerId}`,
            profile_id: action.customerId,
            full_name: null,
            whatsapp_e164: null,
            nickname: action.nickname,
            notify_whatsapp: true,
          },
        ],
      };
    }
    case "client.update":
      return {
        ...state,
        shopClients: state.shopClients.map((row) =>
          row.id === action.id
            ? {
                ...row,
                ...(action.full_name !== undefined ? { full_name: action.full_name } : {}),
                ...(action.whatsapp_e164 !== undefined
                  ? { whatsapp_e164: action.whatsapp_e164 }
                  : {}),
                ...(action.notify_whatsapp !== undefined
                  ? { notify_whatsapp: action.notify_whatsapp }
                  : {}),
              }
            : row,
        ),
      };
    case "survey.record":
      return state.privacy.surveys
        ? {
            ...state,
            lastSurveyAt: action.survey.shown_at,
            surveys: [...state.surveys, action.survey],
          }
        : state;
    case "cancel":
      return {
        ...state,
        waits: state.waits.map((w) =>
          w.appointment_id === action.id ? { ...w, restorable: false } : w,
        ),
        cancellationReasons: {
          ...state.cancellationReasons,
          [action.id]: { reason: action.reason, source: action.source },
        },
        appointments: state.appointments.map((row) =>
          row.id === action.id &&
          (row.status === "pending" ||
            row.status === "confirmed" ||
            row.status === "reschedule_requested")
            ? { ...row, status: "cancelled" }
            : row,
        ),
      };
    case "privacy.request": {
      if (action.status === "requested") {
        if (state.privacyRequests.some((row) => row.status !== "cancelled")) return state;
        const stamp = state.now.toISOString();
        return {
          ...state,
          privacyRequests: [
            ...state.privacyRequests,
            {
              id: crypto.randomUUID(),
              user_id: state.customerId,
              status: "requested",
              created_at: stamp,
              updated_at: stamp,
            },
          ],
        };
      }
      return {
        ...state,
        privacyRequests: state.privacyRequests.map((row) =>
          row.id === action.id && row.status !== "cancelled"
            ? { ...row, status: action.status, updated_at: state.now.toISOString() }
            : row,
        ),
      };
    }
    case "occurrence": {
      const row = state.appointments.find((item) => item.id === action.id);
      if (!row) return state;
      validateOccurrence(
        row,
        state.attendance[action.id] ?? {},
        action.customer,
        action.shop,
        action.noShow,
        state.now,
      );
      return {
        ...state,
        attendance: {
          ...state.attendance,
          [action.id]: {
            ...state.attendance[action.id],
            customer_delay_minutes: action.customer,
            shop_delay_minutes: action.shop,
            no_show_at: action.noShow ? state.now.toISOString() : null,
            occurrence_updated_at: state.now.toISOString(),
            occurrence_recorded_by: "demo-admin",
          },
        },
        appointments: action.noShow
          ? state.appointments.map((item) =>
              item.id === action.id ? { ...item, status: "cancelled" as const } : item,
            )
          : state.appointments,
      };
    }
    case "attendance":
      return {
        ...state,
        attendance: {
          ...state.attendance,
          [action.id]: { ...state.attendance[action.id], [action.stage]: state.now.toISOString() },
        },
        appointments:
          action.stage === "no_show_at"
            ? state.appointments.map((row) =>
                row.id === action.id ? { ...row, status: "cancelled" } : row,
              )
            : state.appointments,
      };
    case "privacy.save":
      return { ...state, privacy: { ...action.preferences } };
    case "privacy.erase":
      return { ...state, privacy: { ...defaultPrivacy }, surveys: [] };
    case "survey.show":
      return state.privacy.surveys
        ? {
            ...state,
            lastSurveyAt: action.survey.shown_at,
            surveys: [...state.surveys, action.survey],
          }
        : state;
    case "survey.answer":
      return state.privacy.surveys
        ? {
            ...state,
            surveys: state.surveys.map((row) =>
              row.id === action.id
                ? {
                    ...row,
                    answer: action.answer,
                    state: action.answer === null ? "dismissed" : "answered",
                  }
                : row,
            ),
          }
        : state;

    case "staff.delete":
      return state.appointments.some((row) => row.staff_id === action.id)
        ? state
        : {
            ...state,
            staff: state.staff.filter((row) => row.id !== action.id),
            availabilityBlocks: state.availabilityBlocks.filter(
              (row) => row.staff_id !== action.id,
            ),
          };
    case "service.delete":
      return state.appointments.some((row) => row.service_id === action.id)
        ? state
        : { ...state, services: state.services.filter((row) => row.id !== action.id) };
    case "service.edit":
      return {
        ...state,
        services: state.services.map((row) =>
          row.id === action.service.id ? action.service : row,
        ),
      };
    case "staff.edit":
      return {
        ...state,
        staff: state.staff.map((row) => (row.id === action.staff.id ? action.staff : row)),
      };
    case "profile.save":
      return {
        ...state,
        customerName: action.name,
        customers: state.customers.map((customer) =>
          customer.id === state.customerId ? { ...customer, name: action.name } : customer,
        ),
      };
    case "book": {
      const terms = demoServiceTerms(
        state,
        action.appointment.staff_id,
        action.appointment.service_id,
      );
      if (!terms) return state;
      const appointment = {
        ...action.appointment,
        ends_at: new Date(
          Date.parse(action.appointment.starts_at) + terms.duration_minutes * 60000,
        ).toISOString(),
        booked_price_cents: terms.price_cents,
      };
      if (
        state.waits.some(
          (w) =>
            blocksSlot(w, state.now) &&
            w.staff_id === appointment.staff_id &&
            w.starts_at < appointment.ends_at &&
            w.ends_at > appointment.starts_at,
        )
      )
        return state;
      return {
        ...state,
        prices: {
          ...state.prices,
          [appointment.id]: appointment.booked_price_cents,
        },
        appointments: [...state.appointments, { ...appointment, status: "confirmed" }],
      };
    }
    case "reschedule": {
      const previous = state.appointments.find((row) => row.id === action.id);
      const terms = demoServiceTerms(state, action.staff_id, action.service_id);
      if (!previous || !terms) return state;
      const endsAt = new Date(
        Date.parse(action.starts_at) + terms.duration_minutes * 60000,
      ).toISOString();
      const price =
        previous.staff_id === action.staff_id && previous.service_id === action.service_id
          ? (previous.booked_price_cents ?? terms.price_cents)
          : terms.price_cents;
      if (
        state.waits.some(
          (w) =>
            blocksSlot(w, state.now) &&
            w.staff_id === action.staff_id &&
            w.starts_at < endsAt &&
            w.ends_at > action.starts_at,
        )
      )
        return state;
      return {
        ...state,
        prices: { ...state.prices, [action.id]: price },
        waits: state.waits.map((w) =>
          w.appointment_id === action.id ? { ...w, restorable: false } : w,
        ),
        appointments: state.appointments.map((row) =>
          row.id === action.id
            ? {
                ...row,
                starts_at: action.starts_at,
                ends_at: endsAt,
                booked_price_cents: price,
                service_id: action.service_id,
                staff_id: action.staff_id,
                status: "confirmed",
              }
            : row,
        ),
      };
    }
    case "status": {
      const appointment = state.appointments.find((row) => row.id === action.id);
      if (!appointment) return state;
      if (action.status === "reschedule_requested") return withdrawDemo(state, action.id);
      if (
        ["pending", "confirmed", "completed"].includes(action.status) &&
        state.waits.some(
          (w) =>
            blocksSlot(w, state.now) &&
            w.staff_id === appointment.staff_id &&
            w.starts_at < appointment.ends_at &&
            w.ends_at > appointment.starts_at,
        )
      )
        return state;
      if (action.status === "completed" && state.attendance[action.id]?.no_show_at) return state;
      const award = action.status === "completed" && !state.awarded.includes(action.id);
      return {
        ...state,
        appointments: state.appointments.map((row) =>
          row.id === action.id ? { ...row, status: action.status } : row,
        ),
        points: state.points + (award && appointment.customer_id === DEMO_CUSTOMER_ID ? 50 : 0),
        awarded: award ? [...state.awarded, action.id] : state.awarded,
      };
    }
    case "service.add":
      return { ...state, services: [...state.services, action.service] };
    case "service.toggle":
      return {
        ...state,
        services: state.services.map((row) =>
          row.id === action.id ? { ...row, active: !row.active } : row,
        ),
      };
    case "staff.add":
      return { ...state, staff: [...state.staff, action.staff] };
    case "staff.toggle":
      return {
        ...state,
        staff: state.staff.map((row) =>
          row.id === action.id ? { ...row, active: !row.active } : row,
        ),
      };
    case "hours.save":
      return { ...state, businessHours: action.hours };
    case "shop.update":
      return {
        ...state,
        shop: { ...state.shop, ...action.shop, updated_at: state.now.toISOString() },
      };
    case "settings.save":
      if (
        !Number.isInteger(action.settings.waiting_cutoff_minutes) ||
        action.settings.waiting_cutoff_minutes < 0 ||
        action.settings.waiting_cutoff_minutes > 1440
      )
        return state;
      return {
        ...(state.settings.waiting_enabled && !action.settings.waiting_enabled
          ? disableWaits(state)
          : state),
        settings: action.settings,
      };
    case "block.add":
      return { ...state, availabilityBlocks: [...state.availabilityBlocks, action.block] };
    case "block.delete":
      return {
        ...state,
        availabilityBlocks: state.availabilityBlocks.filter((row) => row.id !== action.id),
      };
    case "staffService.save":
      return {
        ...state,
        staffServices: [
          ...state.staffServices.filter(
            (row) =>
              !(row.staff_id === action.row.staff_id && row.service_id === action.row.service_id),
          ),
          action.row,
        ],
      };
    case "suggestion.decide":
      return state.decidedSuggestions.includes(action.id)
        ? state
        : { ...state, decidedSuggestions: [...state.decidedSuggestions, action.id] };
  }
}
