import { PwaInstallBanner } from "@/components/pwa-install-banner";
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type CSSProperties,
  type FormEvent,
} from "react";
import {
  ArrowLeft,
  CalendarClock,
  CheckCircle2,
  Gift,
  Hourglass,
  Loader2,
  Lock,
  Minus,
  Pencil,
  Plus,
  PlusCircle,
  RotateCcw,
  Save,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Trash2,
  Trophy,
  Undo2,
  Users,
} from "lucide-react";
import {
  ActionResult,
  ChoiceCards,
  ChoiceChips,
  ConfirmDialog,
  CountBadge,
  DetailList,
  Field,
  FieldMessage,
  IconList,
  InlineStatus,
  LoadingState,
  Notice,
  PersonAvatar,
  SectionHeader,
  StatTile,
  StatusBadge,
  Tag,
  type ActionState,
} from "@/components/visual";
import { toast } from "sonner";
import { TierBadge, TierMedal } from "./TierBadge";
import { useTierBenefit } from "./tier-model";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { brandCornerClass, brandFontScopeClass, brandVariables } from "@/lib/shop/branding";
import { BrandFontFace } from "@/features/shop/BrandFontFace";
import { BrandRootVariables } from "@/features/shop/BrandRootVariables";
import type { SessionProfile } from "@/lib/auth/session";
import { readSavedShopActor, resolveShopActing } from "@/lib/auth/shop-acting";
import { friendlyAuthError } from "@/lib/auth/friendly-error";
import { useI18n, type MessageKey } from "@/lib/i18n";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogScrollArea,
  DialogTitle,
} from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import {
  DEFAULT_TIERS,
  FALLBACK_PROGRAM,
  MAX_TIERS,
  parseLoyaltyProgram,
  tierFor,
  tierStyleKey,
  validateTiers,
  type LoyaltyProgram,
  type LoyaltyReward,
  type LoyaltyTier,
  type TierProblem,
} from "./program";

type Part = "regras" | "recompensas" | "clientes" | "resgates";

type CustomerRow = {
  user_id: string;
  full_name: string | null;
  points: number;
  lifetime_points: number;
  updated_at: string;
};

type RedemptionRow = {
  id: string;
  user_id: string;
  full_name: string | null;
  reward_name: string;
  cost_points: number;
  status: string;
  created_at: string;
  expires_at: string;
};

const fieldClass =
  "w-full rounded-xl border border-border bg-background px-3 py-2 text-sm font-normal";

const TIER_PROBLEM_KEY: Record<TierProblem, MessageKey> = {
  count: "loyalty.admin.tierProblem.count",
  first: "loyalty.admin.tierProblem.first",
  order: "loyalty.admin.tierProblem.order",
  name: "loyalty.admin.tierProblem.name",
  duplicate: "loyalty.admin.tierProblem.duplicate",
  benefit: "loyalty.admin.tierProblem.benefit",
};

function clampInt(value: string, min: number, max: number) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return min;
  return Math.max(min, Math.min(max, parsed));
}

export function LoyaltyAdminPage({
  profile,
  embedded = false,
  selectedActorId,
}: {
  profile: SessionProfile;
  embedded?: boolean;
  selectedActorId?: string | null;
}) {
  const { t, intlLocale } = useI18n();
  // Mesma regra do painel (lib/auth/shop-acting): a loja escolhida no aparelho por esta conta,
  // ou o shop_admin antigo; nunca uma loja vinda de vínculo de cliente.
  const acting = useMemo(
    () =>
      resolveShopActing({
        actors: profile.shopActors,
        memberships: profile.memberships,
        selectedActorId:
          selectedActorId === undefined ? readSavedShopActor(profile.user.id) : selectedActorId,
      }),
    [profile, selectedActorId],
  );
  const actor = acting.actor;
  const shop = acting.shop;
  // Sem vínculo de equipe (shop_admin legado), o servidor só deixa o admin da plataforma gerir:
  // loyalty_can_manage aceita is_platform_admin() ou shop_member owner/partner.
  const canManage = actor
    ? actor.role === "owner" || actor.role === "partner"
    : profile.memberships.some((m) => m.role === "platform_admin");

  // Parte pedida no endereço (?parte=resgates…), vinda dos atalhos de Ajustes.
  const [requestedPart] = useState<Part | null>(() => {
    if (typeof window === "undefined") return null;
    const value = new URLSearchParams(window.location.search).get("parte");
    return value === "regras" ||
      value === "recompensas" ||
      value === "clientes" ||
      value === "resgates"
      ? value
      : null;
  });
  const [part, setPart] = useState<Part>(
    requestedPart && (canManage || requestedPart === "resgates" || requestedPart === "clientes")
      ? requestedPart
      : canManage
        ? "regras"
        : "resgates",
  );
  const [partChosen, setPartChosen] = useState(Boolean(requestedPart));
  const [program, setProgram] = useState<LoyaltyProgram | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  // Identidade da loja (modo de canto, cores e fontes), igual à raiz do ShopShell.
  const [settings, setSettings] = useState<Tables<"barbershop_settings"> | null>(null);

  useEffect(() => {
    if (!shop?.id) return;
    let active = true;
    void supabase
      .from("barbershop_settings")
      .select("*")
      .eq("barbershop_id", shop.id)
      .maybeSingle()
      .then(({ data }) => {
        if (active) setSettings(data ?? null);
      });
    return () => {
      active = false;
    };
  }, [shop?.id]);

  const loadProgram = useCallback(async () => {
    if (!shop?.id) return;
    setLoadError(null);
    const { data, error } = await supabase.rpc("get_shop_loyalty_program", {
      p_shop_id: shop.id,
    });
    if (error) setLoadError(friendlyAuthError(error, t("loyalty.admin.loadError")));
    else setProgram(parseLoyaltyProgram(data));
    setLoading(false);
  }, [shop?.id, t]);

  useEffect(() => {
    void loadProgram();
  }, [loadProgram]);

  // Resgates esperando entrega: uma consulta para o contador da aba, o resumo e a lista.
  const [redemptions, setRedemptions] = useState<RedemptionRow[] | null>(null);
  const [redemptionsError, setRedemptionsError] = useState<string | null>(null);
  const loadRedemptions = useCallback(async () => {
    if (!shop?.id) return;
    const { data, error: rpcError } = await supabase.rpc("list_shop_loyalty_redemptions", {
      p_shop_id: shop.id,
      p_status: "pending",
    });
    if (rpcError) setRedemptionsError(friendlyAuthError(rpcError, t("loyalty.admin.loadError")));
    else {
      setRedemptionsError(null);
      setRedemptions((data ?? []) as RedemptionRow[]);
    }
  }, [shop?.id, t]);
  useEffect(() => {
    void loadRedemptions();
  }, [loadRedemptions]);
  const pendingCount = redemptions?.length ?? 0;

  // Abre em Resgates quando há prêmios esperando entrega (a não ser que a pessoa já tenha escolhido).
  useEffect(() => {
    if (!partChosen && pendingCount > 0) setPart("resgates");
  }, [partChosen, pendingCount]);

  function choosePart(next: Part) {
    setPart(next);
    setPartChosen(true);
  }

  const parts: Array<{ id: Part; label: string; icon: typeof Gift }> = [
    ...(canManage
      ? [
          { id: "regras" as const, label: t("loyalty.admin.part.rules"), icon: Trophy },
          { id: "recompensas" as const, label: t("loyalty.admin.part.rewards"), icon: Gift },
        ]
      : []),
    { id: "resgates", label: t("loyalty.admin.part.redemptions"), icon: ShieldCheck },
    { id: "clientes", label: t("loyalty.admin.part.customers"), icon: Users },
  ];

  const brandStyle = settings
    ? brandVariables(
        settings.primary_color,
        settings.accent_color,
        settings.font_family,
        settings.custom_font_url,
        settings.header_font_weight,
        settings.header_font_style,
        settings.corner_style,
      )
    : null;

  return (
    <div
      className={`${embedded ? "" : "arena-workspace min-h-dvh bg-background"} text-foreground ${brandFontScopeClass(settings?.font_scope)} ${brandCornerClass(settings?.corner_style)}`}
      style={brandStyle ? (brandStyle as CSSProperties) : undefined}
    >
      <BrandRootVariables vars={brandStyle} />
      {settings && (
        <BrandFontFace url={settings.custom_font_url} faces={settings.custom_font_faces} />
      )}
      {!embedded && (
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-border bg-background/90 px-4 py-4 backdrop-blur-xl">
          <a
            href="/shop?secao=pontos"
            className="app-icon-button shrink-0"
            aria-label={t("loyalty.admin.back")}
          >
            <ArrowLeft className="size-5" aria-hidden />
          </a>
          <div className="min-w-0">
            <p className="truncate text-xs font-bold text-gold">{shop?.name ?? ""}</p>
            <h1 className="truncate text-lg font-extrabold tracking-tight">
              {t("loyalty.admin.title")}
            </h1>
          </div>
        </header>
      )}

      <main
        className={
          embedded
            ? "loyalty-admin-content space-y-5"
            : "loyalty-admin-content mx-auto max-w-3xl space-y-5 p-4 pb-10"
        }
      >
        {!embedded && <PwaInstallBanner />}
        {!shop ? (
          <EmptyState tone="bell" title={t("loyalty.admin.noShop")} />
        ) : loading ? (
          <LoadingState variant="stats" count={4} label={t("loyalty.admin.loading")} />
        ) : loadError ? (
          <EmptyState
            status="danger"
            title={t("loyalty.admin.loadFailedTitle")}
            description={loadError}
            action={
              <button
                type="button"
                className="action-button action-confirm"
                onClick={() => void loadProgram()}
              >
                <RotateCcw className="size-4" aria-hidden />
                {t("loyalty.admin.retry")}
              </button>
            }
          />
        ) : program && !program.enabled ? (
          <>
            <EmptyState
              tone="gift"
              title={t("loyalty.admin.disabledTitle")}
              description={t("loyalty.admin.disabledText")}
            />
            {/* Resgates feitos antes do desligamento continuam podendo ser entregues ou cancelados. */}
            <RedemptionsPart
              rows={redemptions}
              error={redemptionsError}
              onReload={loadRedemptions}
              intlLocale={intlLocale}
            />
          </>
        ) : program ? (
          <>
            {/* Resumo do clube: o essencial à vista, e o que pede ação (resgates) leva direto à aba. */}
            <div className="loyalty-admin-stats grid grid-cols-2 gap-2 sm:grid-cols-4">
              <StatTile
                icon={Star}
                label={t("loyalty.admin.stat.perVisit")}
                value={t("loyalty.admin.stat.points", { n: program.points_per_visit })}
              />
              <StatTile
                icon={Trophy}
                label={t("loyalty.admin.stat.levels")}
                value={program.tiers.length}
                hint={program.tiers.map((tier) => tier.name).join(" · ")}
              />
              <StatTile
                icon={Gift}
                label={t("loyalty.admin.stat.rewards")}
                value={program.rewards.filter((reward) => reward.active).length}
                onClick={canManage ? () => choosePart("recompensas") : undefined}
              />
              <StatTile
                icon={Hourglass}
                label={t("loyalty.admin.stat.waiting")}
                value={redemptions ? pendingCount : undefined}
                loading={!redemptions && !redemptionsError}
                // Mesmo tom âmbar do selo "esperando entrega" no menu de Ajustes.
                tone={pendingCount > 0 ? "pending" : undefined}
                onClick={() => choosePart("resgates")}
                pressed={part === "resgates"}
              />
            </div>
            <nav
              className="loyalty-admin-nav grid grid-cols-2 gap-1 rounded-2xl border border-border bg-card p-1 sm:grid-cols-4"
              aria-label={t("loyalty.admin.partsLabel")}
            >
              {parts.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => choosePart(id)}
                  aria-pressed={part === id}
                  className={cn(
                    "flex min-h-11 items-center justify-center gap-2 rounded-xl px-3 text-sm font-bold transition-colors",
                    part === id
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground",
                  )}
                >
                  <Icon className="size-4 shrink-0" aria-hidden />
                  {label}
                  {id === "resgates" && (
                    <CountBadge
                      count={pendingCount}
                      tone="pending"
                      label={t(
                        pendingCount === 1
                          ? "loyalty.admin.waitingOne"
                          : "loyalty.admin.waitingMany",
                        { count: pendingCount },
                      )}
                    />
                  )}
                </button>
              ))}
            </nav>

            {part === "regras" && canManage && (
              <RulesPart shopId={shop.id} program={program} onSaved={setProgram} />
            )}
            {part === "recompensas" && canManage && (
              <RewardsPart shopId={shop.id} program={program} onChanged={loadProgram} />
            )}
            {part === "resgates" && (
              <RedemptionsPart
                rows={redemptions}
                error={redemptionsError}
                onReload={loadRedemptions}
                intlLocale={intlLocale}
              />
            )}
            {part === "clientes" && (
              <CustomersPart
                shopId={shop.id}
                program={program}
                canAdjust={canManage}
                myId={profile.user.id}
              />
            )}
          </>
        ) : null}
      </main>
    </div>
  );
}

function RulesPart({
  shopId,
  program,
  onSaved,
}: {
  shopId: string;
  program: LoyaltyProgram;
  onSaved: (program: LoyaltyProgram) => void;
}) {
  const { t } = useI18n();
  const [mode, setMode] = useState(program.mode);
  const [perVisit, setPerVisit] = useState(String(program.points_per_visit));
  const [welcome, setWelcome] = useState(String(program.welcome_bonus));
  const [tiers, setTiers] = useState<LoyaltyTier[]>(program.tiers);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ActionState | null>(null);

  const custom = mode === "custom";
  const problem = custom ? validateTiers(tiers) : null;
  const dirty =
    mode !== program.mode ||
    (custom &&
      (clampInt(perVisit, 1, 1000) !== program.points_per_visit ||
        clampInt(welcome, 0, 1000) !== program.welcome_bonus ||
        JSON.stringify(tiers) !== JSON.stringify(program.tiers)));
  const shownTiers = custom ? tiers : DEFAULT_TIERS;
  const shownPerVisit = custom ? clampInt(perVisit, 1, 1000) : FALLBACK_PROGRAM.points_per_visit;
  const shownWelcome = custom ? clampInt(welcome, 0, 1000) : FALLBACK_PROGRAM.welcome_bonus;
  const previewProgram: LoyaltyProgram = {
    ...program,
    mode,
    tiers: shownTiers,
    points_per_visit: shownPerVisit,
    welcome_bonus: shownWelcome,
  };
  const benefitFor = useTierBenefit(previewProgram);
  /** Em qual atendimento o cliente chega a cada nível, pela regra mostrada. */
  const visitFor = (min: number) =>
    min <= shownWelcome ? 0 : Math.ceil((min - shownWelcome) / Math.max(1, shownPerVisit));

  function updateTier(index: number, patch: Partial<LoyaltyTier>) {
    setTiers((current) => current.map((tier, i) => (i === index ? { ...tier, ...patch } : tier)));
  }

  function addTier() {
    setTiers((current) => {
      if (current.length >= MAX_TIERS) return current;
      const last = current[current.length - 1];
      return [...current, { name: "", min_points: (last?.min_points ?? 0) + 100, benefit: "" }];
    });
  }

  function save(event: FormEvent) {
    event.preventDefault();
    void saveRules();
  }

  async function saveRules() {
    if (problem || saving) return;
    setSaving(true);
    setError(null);
    setResult(null);
    const { data: savedData, error: rpcError } = await supabase.rpc("save_loyalty_program", {
      p_shop_id: shopId,
      p_mode: mode,
      p_points_per_visit: clampInt(perVisit, 1, 1000),
      p_welcome_bonus: clampInt(welcome, 0, 1000),
      p_tiers: (custom ? tiers : DEFAULT_TIERS).map((tier) => ({
        name: tier.name.trim(),
        min_points: tier.min_points,
        benefit: tier.benefit.trim(),
      })),
    });
    if (rpcError) {
      setError(friendlyAuthError(rpcError, t("loyalty.admin.saveError")));
      setResult("error");
      setSaving(false);
      return;
    }
    const { data, error: reloadError } = await supabase.rpc("get_shop_loyalty_program", {
      p_shop_id: shopId,
    });
    let next: LoyaltyProgram | null = null;
    if (!reloadError && data && typeof data === "object" && !Array.isArray(data)) {
      next = parseLoyaltyProgram(data);
    } else if (savedData && typeof savedData === "object" && !Array.isArray(savedData)) {
      // A releitura falhou: usa a regra efetiva devolvida pelo próprio save e mantém
      // o estado do clube e os prêmios já carregados.
      next = {
        ...parseLoyaltyProgram(savedData),
        enabled: program.enabled,
        rewards: program.rewards,
      };
    }
    if (next) {
      onSaved(next);
      setMode(next.mode);
      setTiers(next.tiers);
      setPerVisit(String(next.points_per_visit));
      setWelcome(String(next.welcome_bonus));
    }
    setSaving(false);
    setResult("saved");
  }

  /** Campo de número com − e + (44 px), para pontos por atendimento e bônus. */
  function stepper(
    label: string,
    hint: string,
    value: string,
    setValue: (next: string) => void,
    min: number,
    step: number,
  ) {
    const current = clampInt(value, min, 1000);
    return (
      <Field label={label} hint={hint}>
        {(props) => (
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={current <= min}
              onClick={() => setValue(String(Math.max(min, current - step)))}
              aria-label={t("loyalty.admin.less", { label })}
              className="grid size-11 shrink-0 place-items-center rounded-xl border border-border disabled:opacity-40"
            >
              <Minus className="size-4" aria-hidden />
            </button>
            <input
              {...props}
              type="number"
              inputMode="numeric"
              min={min}
              max={1000}
              required
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className={`${fieldClass} min-h-11 min-w-0 flex-1 text-center text-lg font-bold tabular-nums`}
            />
            <button
              type="button"
              disabled={current >= 1000}
              onClick={() => setValue(String(Math.min(1000, current + step)))}
              aria-label={t("loyalty.admin.more", { label })}
              className="grid size-11 shrink-0 place-items-center rounded-xl border border-border disabled:opacity-40"
            >
              <Plus className="size-4" aria-hidden />
            </button>
          </div>
        )}
      </Field>
    );
  }

  return (
    <form onSubmit={save} className="loyalty-rules space-y-4">
      <div className="loyalty-rule-options space-y-4">
        <section className="app-action-card space-y-4 p-5" aria-labelledby="loyalty-mode-title">
          <SectionHeader
            icon={Trophy}
            id="loyalty-mode-title"
            title={t("loyalty.admin.modeTitle")}
            description={t("loyalty.admin.modeIntro")}
          />
          <ChoiceCards
            legend={t("loyalty.admin.modeTitle")}
            name="loyalty-mode"
            value={mode}
            disabled={saving}
            onChange={(option) => {
              setMode(option);
              setResult(null);
              if (option === "default") setTiers(DEFAULT_TIERS);
            }}
            options={(["default", "custom"] as const).map((option) => ({
              value: option,
              icon: option === "default" ? Sparkles : Pencil,
              title: t(
                option === "default" ? "loyalty.admin.modeDefault" : "loyalty.admin.modeCustom",
              ),
              description: t(
                option === "default"
                  ? "loyalty.admin.modeDefaultHint"
                  : "loyalty.admin.modeCustomHint",
              ),
            }))}
          />
        </section>

        {/* Pontos: cartões de número; na regra padrão ficam só para leitura. */}
        {custom ? (
          <div className="grid gap-3 rounded-2xl border border-border bg-card p-4 sm:grid-cols-2">
            {stepper(
              t("loyalty.admin.perVisit"),
              t("loyalty.admin.perVisitHint"),
              perVisit,
              setPerVisit,
              1,
              5,
            )}
            {stepper(
              t("loyalty.admin.welcome"),
              t("loyalty.admin.welcomeHint"),
              welcome,
              setWelcome,
              0,
              10,
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <StatTile
              icon={Star}
              label={t("loyalty.admin.perVisit")}
              value={t("loyalty.admin.stat.points", { n: FALLBACK_PROGRAM.points_per_visit })}
            />
            <StatTile
              icon={Gift}
              label={t("loyalty.admin.welcome")}
              value={t("loyalty.admin.stat.points", { n: FALLBACK_PROGRAM.welcome_bonus })}
            />
          </div>
        )}
      </div>

      <section className="loyalty-ladder space-y-3 rounded-2xl border border-border bg-card p-4">
        <div className="flex flex-wrap items-start gap-2">
          <div className="min-w-0 flex-1 basis-40">
            <h2 className="text-sm font-bold">{t("loyalty.admin.tiersTitle")}</h2>
            <p className="text-xs text-muted-foreground">{t("loyalty.admin.tiersHint")}</p>
          </div>
          {!custom && (
            <StatusBadge tone="neutral" icon={Lock} label={t("loyalty.admin.readOnly")} size="sm" />
          )}
        </div>

        {/* Escada de níveis: selo em gradiente, a partir de quantos pontos e em qual atendimento. */}
        <ol className="space-y-2" aria-label={t("loyalty.admin.ladderAria")}>
          {shownTiers.map((tier, index) => {
            const visit = visitFor(tier.min_points);
            const benefit = benefitFor(index);
            return (
              <li
                key={`${tier.name}-${index}`}
                className="flex items-start gap-3 rounded-xl border border-border/70 p-3"
              >
                <TierMedal tier={tierStyleKey(index, shownTiers.length)} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <TierBadge
                      tier={tierStyleKey(index, shownTiers.length)}
                      name={tier.name || t("loyalty.admin.tierN", { n: index + 1 })}
                      size="sm"
                    />
                    <Tag>{t("loyalty.admin.fromPoints", { n: tier.min_points })}</Tag>
                    <span className="text-xs font-semibold text-muted-foreground">
                      {visit <= 0
                        ? t("loyalty.admin.fromStart")
                        : t("loyalty.admin.atVisit", { n: visit })}
                    </span>
                  </div>
                  {benefit && <p className="mt-1 text-xs text-muted-foreground">{benefit}</p>}
                </div>
              </li>
            );
          })}
        </ol>
        {!custom && (
          <button
            type="button"
            onClick={() => {
              setMode("custom");
              setResult(null);
            }}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-border px-3 text-sm font-bold transition hover:border-primary/40"
          >
            <Pencil className="size-4" aria-hidden />
            {t("loyalty.admin.customize")}
          </button>
        )}
      </section>

      {custom && (
        <section className="space-y-3 rounded-2xl border border-border bg-card p-4">
          <h2 className="text-sm font-bold">{t("loyalty.admin.editTiers")}</h2>
          <ol className="space-y-3">
            {tiers.map((tier, index) => (
              <li key={index} className="space-y-2 rounded-xl border border-border p-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2 text-xs font-bold text-muted-foreground">
                    <TierMedal tier={tierStyleKey(index, tiers.length)} size="sm" />
                    {t("loyalty.admin.tierN", { n: index + 1 })}
                  </span>
                  {custom && index > 0 && (
                    <button
                      type="button"
                      onClick={() => setTiers((current) => current.filter((_, i) => i !== index))}
                      className="flex size-11 items-center justify-center rounded-xl text-destructive"
                      aria-label={t("loyalty.admin.tierRemove", { n: index + 1 })}
                    >
                      <Trash2 className="size-4" aria-hidden />
                    </button>
                  )}
                </div>
                <div className="grid gap-2 sm:grid-cols-[1fr_8rem]">
                  <label className="block space-y-1 text-xs font-semibold">
                    {t("loyalty.admin.tierName")}
                    <input
                      value={tier.name}
                      disabled={!custom}
                      maxLength={30}
                      required
                      onChange={(e) => updateTier(index, { name: e.target.value })}
                      className={fieldClass}
                    />
                  </label>
                  <label className="block space-y-1 text-xs font-semibold">
                    {t("loyalty.admin.tierMin")}
                    <input
                      type="number"
                      inputMode="numeric"
                      min={0}
                      value={tier.min_points}
                      disabled={!custom || index === 0}
                      onChange={(e) =>
                        updateTier(index, { min_points: clampInt(e.target.value, 0, 1000000) })
                      }
                      className={fieldClass}
                    />
                  </label>
                </div>
                <label className="block space-y-1 text-xs font-semibold">
                  {t("loyalty.admin.tierBenefit")}
                  <input
                    value={tier.benefit}
                    disabled={!custom}
                    maxLength={160}
                    placeholder={t("loyalty.admin.tierBenefitPlaceholder")}
                    onChange={(e) => updateTier(index, { benefit: e.target.value })}
                    className={fieldClass}
                  />
                </label>
              </li>
            ))}
          </ol>
          {custom && tiers.length < MAX_TIERS && (
            <button
              type="button"
              onClick={addTier}
              className="flex min-h-11 items-center gap-2 rounded-xl border border-border px-3 text-sm font-bold"
            >
              <Plus className="size-4" aria-hidden />
              {t("loyalty.admin.tierAdd")}
            </button>
          )}
          {problem && <Notice tone="danger" title={t(TIER_PROBLEM_KEY[problem])} />}
        </section>
      )}

      <IconList
        items={[{ icon: CheckCircle2, tone: "success", text: t("loyalty.admin.noRetroactive") }]}
      />
      <button
        type="submit"
        disabled={saving || Boolean(problem) || !dirty}
        aria-busy={saving || undefined}
        className="action-button action-confirm w-full sm:w-auto sm:px-6"
      >
        {saving ? (
          <Loader2 className="size-4 motion-safe:animate-spin" aria-hidden />
        ) : (
          <Save className="size-4" aria-hidden />
        )}
        {saving ? t("common.saving") : t("loyalty.admin.saveRules")}
      </button>
      <ActionResult
        state={result}
        text={result === "error" ? (error ?? undefined) : t("loyalty.admin.saved")}
        onRetry={() => void saveRules()}
      />
    </form>
  );
}

function RewardsPart({
  shopId,
  program,
  onChanged,
}: {
  shopId: string;
  program: LoyaltyProgram;
  onChanged: () => Promise<void>;
}) {
  const { t } = useI18n();
  const [editing, setEditing] = useState<LoyaltyReward | "new" | null>(null);
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [toggleState, setToggleState] = useState<{ id: string; state: ActionState } | null>(null);

  async function toggle(reward: LoyaltyReward) {
    setTogglingId(reward.id);
    setToggleState({ id: reward.id, state: "saving" });
    const { error } = await supabase.rpc("save_loyalty_reward", {
      p_shop_id: shopId,
      p_reward_id: reward.id,
      p_name: reward.name,
      p_description: reward.description,
      p_cost_points: reward.cost_points,
      p_active: !reward.active,
      p_sort_order: reward.sort_order,
    });
    setToggleState({ id: reward.id, state: error ? "error" : "saved" });
    await onChanged();
    setTogglingId(null);
  }

  return (
    <section className="space-y-3">
      <p className="text-sm text-muted-foreground">{t("loyalty.admin.rewardsHint")}</p>
      {program.rewards.length === 0 ? (
        <EmptyState
          tone="gift"
          title={t("loyalty.admin.rewardsEmpty")}
          description={t("loyalty.admin.rewardsEmptyText")}
        />
      ) : (
        <ul className="space-y-2">
          {program.rewards.map((reward) => (
            <li
              key={reward.id}
              className={cn(
                "flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3",
                !reward.active && "bg-muted/40",
              )}
            >
              <span
                aria-hidden
                className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-gold"
              >
                <Gift className="size-5" />
              </span>
              <div className="min-w-0 flex-1 basis-32">
                <p className="truncate text-sm font-bold">{reward.name}</p>
                <div className="mt-1 flex flex-wrap items-center gap-1.5">
                  <Tag icon={Star}>
                    {t(
                      reward.cost_points === 1
                        ? "loyalty.admin.rewardCostOne"
                        : "loyalty.admin.rewardCostMany",
                      { n: reward.cost_points },
                    )}
                  </Tag>
                  <StatusBadge
                    tone={reward.active ? "success" : "neutral"}
                    variant="dot"
                    label={t(
                      reward.active ? "loyalty.admin.rewardVisible" : "loyalty.admin.rewardPaused",
                    )}
                  />
                  {toggleState?.id === reward.id && (
                    <InlineStatus state={toggleState.state} onRetry={() => void toggle(reward)} />
                  )}
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditing(reward)}
                  aria-label={t("loyalty.admin.rewardEditOf", { name: reward.name })}
                  className="inline-flex min-h-11 items-center gap-1.5 rounded-xl border border-border px-3 text-xs font-semibold transition hover:border-primary/40"
                >
                  <Pencil className="size-3.5" aria-hidden />
                  {t("loyalty.admin.edit")}
                </button>
                <Switch
                  checked={reward.active}
                  disabled={togglingId === reward.id}
                  onCheckedChange={() => void toggle(reward)}
                  aria-label={t("loyalty.admin.rewardToggle", { name: reward.name })}
                />
              </div>
            </li>
          ))}
        </ul>
      )}
      {program.rewards.length < 30 && (
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="action-button action-confirm w-full sm:w-auto sm:px-6"
        >
          <Plus className="size-4" aria-hidden />
          {t("loyalty.admin.rewardAdd")}
        </button>
      )}
      {editing && (
        <RewardDialog
          shopId={shopId}
          reward={editing === "new" ? null : editing}
          nextOrder={program.rewards.length}
          onClose={() => setEditing(null)}
          onSaved={async () => {
            setEditing(null);
            await onChanged();
          }}
        />
      )}
    </section>
  );
}

function RewardDialog({
  shopId,
  reward,
  nextOrder,
  onClose,
  onSaved,
}: {
  shopId: string;
  reward: LoyaltyReward | null;
  nextOrder: number;
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const { t } = useI18n();
  const [name, setName] = useState(reward?.name ?? "");
  const [description, setDescription] = useState(reward?.description ?? "");
  const [cost, setCost] = useState(String(reward?.cost_points ?? 100));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError(null);
    const { error: rpcError } = await supabase.rpc("save_loyalty_reward", {
      p_shop_id: shopId,
      p_reward_id: reward?.id ?? null,
      p_name: name.trim(),
      p_description: description.trim(),
      p_cost_points: clampInt(cost, 1, 100000),
      p_active: reward?.active ?? true,
      p_sort_order: reward?.sort_order ?? nextOrder,
    });
    setSaving(false);
    if (rpcError) {
      setError(friendlyAuthError(rpcError, t("loyalty.admin.saveError")));
      return;
    }
    toast.success(t("loyalty.admin.rewardSaved"));
    await onSaved();
  }

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogTitle>
          {t(reward ? "loyalty.admin.rewardEdit" : "loyalty.admin.rewardAdd")}
        </DialogTitle>
        <DialogDescription>{t("loyalty.admin.rewardDialogHint")}</DialogDescription>
        <DialogScrollArea>
          <form id="reward-form" onSubmit={save} className="space-y-3">
            <label className="block space-y-1 text-xs font-semibold">
              {t("loyalty.admin.rewardName")}
              <input
                value={name}
                required
                minLength={2}
                maxLength={60}
                placeholder={t("loyalty.admin.rewardNamePlaceholder")}
                onChange={(e) => setName(e.target.value)}
                className={fieldClass}
              />
            </label>
            <label className="block space-y-1 text-xs font-semibold">
              {t("loyalty.admin.rewardDescription")}
              <textarea
                value={description}
                maxLength={200}
                rows={2}
                onChange={(e) => setDescription(e.target.value)}
                className={fieldClass}
              />
            </label>
            <label className="block space-y-1 text-xs font-semibold">
              {t("loyalty.admin.rewardCostLabel")}
              <input
                type="number"
                inputMode="numeric"
                min={1}
                max={100000}
                required
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                className={fieldClass}
              />
              <span className="block font-normal text-muted-foreground">
                {t("loyalty.admin.rewardCostHint")}
              </span>
            </label>
            {error && (
              <p className="text-sm font-semibold text-destructive" role="alert">
                {error}
              </p>
            )}
          </form>
        </DialogScrollArea>
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={onClose}
            className="min-h-11 rounded-xl border border-border px-4 text-sm font-bold"
          >
            {t("loyalty.admin.cancel")}
          </button>
          <button
            type="submit"
            form="reward-form"
            disabled={saving}
            className="action-button action-confirm"
          >
            {saving && <Loader2 className="size-4 animate-spin" aria-hidden />}
            {t("loyalty.admin.rewardSave")}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Dias inteiros até a data (0 = hoje, 1 = amanhã), no calendário do aparelho. */
function daysUntil(value: string) {
  const end = new Date(value);
  const today = new Date();
  const a = Date.UTC(end.getFullYear(), end.getMonth(), end.getDate());
  const b = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate());
  return Math.round((a - b) / 86_400_000);
}

function RedemptionsPart({
  rows,
  error,
  onReload,
  intlLocale,
}: {
  rows: RedemptionRow[] | null;
  error: string | null;
  onReload: () => Promise<void>;
  intlLocale: string;
}) {
  const { t } = useI18n();
  const [busyId, setBusyId] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState<RedemptionRow | null>(null);
  const [result, setResult] = useState<{ state: ActionState; text: string } | null>(null);

  async function resolve(row: RedemptionRow, action: "fulfill" | "cancel") {
    setBusyId(row.id);
    const { error: rpcError } = await supabase.rpc("resolve_loyalty_redemption", {
      p_redemption_id: row.id,
      p_action: action,
    });
    setBusyId(null);
    if (rpcError) {
      const message = friendlyAuthError(rpcError, t("loyalty.admin.saveError"));
      if (action === "cancel") throw new Error(message);
      setResult({ state: "error", text: message });
      return;
    }
    const name = row.full_name || t("loyalty.admin.customerUnnamed");
    setResult({
      state: "saved",
      text:
        action === "fulfill"
          ? t("loyalty.admin.redeemFulfilledOf", { reward: row.reward_name, name })
          : t("loyalty.admin.redeemCancelledOf", { n: row.cost_points, name }),
    });
    await onReload();
  }

  const dateFormat = new Intl.DateTimeFormat(intlLocale, { day: "2-digit", month: "short" });

  if (error)
    return (
      <Notice
        tone="danger"
        title={error}
        action={{ label: t("visual.retry"), icon: RotateCcw, onClick: () => void onReload() }}
      />
    );
  if (!rows) return <LoadingState variant="list" count={2} label={t("loyalty.admin.loading")} />;

  return (
    <section className="space-y-3">
      <p className="text-sm text-muted-foreground">{t("loyalty.admin.redemptionsHint")}</p>
      <ActionResult
        state={result?.state}
        text={result?.text}
        onDismiss={() => setResult(null)}
        autoHideMs={6000}
      />
      {rows.length === 0 ? (
        <EmptyState
          status="success"
          title={t("loyalty.admin.redemptionsEmpty")}
          description={t("loyalty.admin.redemptionsEmptyText")}
        />
      ) : (
        <ul className="space-y-2">
          {rows.map((row) => {
            const name = row.full_name || t("loyalty.admin.customerUnnamed");
            const days = daysUntil(row.expires_at);
            return (
              <li key={row.id} className="space-y-3 rounded-2xl border border-border bg-card p-4">
                <div className="flex items-start gap-3">
                  <PersonAvatar name={name} seed={row.user_id} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold">{name}</p>
                    <p className="flex flex-wrap items-center gap-1.5 text-sm">
                      <Gift className="size-4 shrink-0 text-gold" aria-hidden />
                      <span className="min-w-0 break-words">{row.reward_name}</span>
                    </p>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      <Tag icon={Star}>
                        {t("loyalty.admin.stat.points", { n: row.cost_points })}
                      </Tag>
                      {days <= 0 ? (
                        <StatusBadge
                          tone="danger"
                          icon={CalendarClock}
                          size="sm"
                          label={t("loyalty.admin.expiresToday")}
                        />
                      ) : days === 1 ? (
                        <StatusBadge
                          tone="warning"
                          icon={CalendarClock}
                          size="sm"
                          label={t("loyalty.admin.expiresTomorrow")}
                        />
                      ) : (
                        <StatusBadge
                          tone="neutral"
                          icon={CalendarClock}
                          size="sm"
                          label={t("loyalty.admin.expiresOn", {
                            date: dateFormat.format(new Date(row.expires_at)),
                          })}
                        />
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row-reverse sm:items-center">
                  <button
                    type="button"
                    disabled={busyId === row.id}
                    onClick={() => void resolve(row, "fulfill")}
                    aria-busy={busyId === row.id || undefined}
                    className="action-button action-success w-full sm:w-auto sm:px-5"
                  >
                    {busyId === row.id ? (
                      <Loader2 className="size-4 motion-safe:animate-spin" aria-hidden />
                    ) : (
                      <CheckCircle2 className="size-4" aria-hidden />
                    )}
                    {t("loyalty.admin.redeemFulfill")}
                  </button>
                  <button
                    type="button"
                    disabled={busyId === row.id}
                    onClick={() => setCancelling(row)}
                    className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-xl px-3 text-sm font-semibold text-muted-foreground transition hover:text-destructive"
                  >
                    <Undo2 className="size-4" aria-hidden />
                    {t("loyalty.admin.redeemCancel")}
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <ConfirmDialog
        open={Boolean(cancelling)}
        onOpenChange={(open) => !open && setCancelling(null)}
        tone="danger"
        icon={Undo2}
        title={t("loyalty.admin.cancelTitle")}
        description={cancelling?.reward_name}
        consequences={
          cancelling
            ? [
                {
                  icon: Undo2,
                  tone: "success",
                  text: t("loyalty.admin.cancelReturns", {
                    n: cancelling.cost_points,
                    name: cancelling.full_name || t("loyalty.admin.customerUnnamed"),
                  }),
                },
                { icon: Gift, tone: "danger", text: t("loyalty.admin.cancelNoReward") },
              ]
            : undefined
        }
        confirmLabel={t("loyalty.admin.cancelConfirm")}
        confirmIcon={Undo2}
        cancelLabel={t("loyalty.admin.cancelKeep")}
        onConfirm={async () => {
          if (cancelling) await resolve(cancelling, "cancel");
        }}
      />
    </section>
  );
}

function CustomersPart({
  shopId,
  program,
  canAdjust,
  myId,
}: {
  shopId: string;
  program: LoyaltyProgram;
  canAdjust: boolean;
  myId: string;
}) {
  const { t } = useI18n();
  const [search, setSearch] = useState("");
  const [rows, setRows] = useState<CustomerRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [adjusting, setAdjusting] = useState<CustomerRow | null>(null);

  const load = useCallback(
    async (query: string) => {
      const { data, error: rpcError } = await supabase.rpc("list_shop_loyalty_customers", {
        p_shop_id: shopId,
        p_search: query || null,
        p_limit: 50,
      });
      if (rpcError) setError(friendlyAuthError(rpcError, t("loyalty.admin.loadError")));
      else {
        setError(null);
        setRows((data ?? []) as CustomerRow[]);
      }
    },
    [shopId, t],
  );

  useEffect(() => {
    const timer = window.setTimeout(() => void load(search.trim()), 300);
    return () => window.clearTimeout(timer);
  }, [load, search]);

  return (
    <section className="space-y-3">
      <label className="relative block">
        <span className="sr-only">{t("loyalty.admin.customerSearch")}</span>
        <Search
          className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden
        />
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t("loyalty.admin.customerSearch")}
          className={`${fieldClass} min-h-11 pl-9`}
        />
      </label>
      {error ? (
        <Notice
          tone="danger"
          title={error}
          action={{
            label: t("visual.retry"),
            icon: RotateCcw,
            onClick: () => void load(search.trim()),
          }}
        />
      ) : !rows ? (
        <LoadingState variant="list" count={3} label={t("loyalty.admin.loading")} />
      ) : rows.length === 0 ? (
        <EmptyState
          tone={search.trim() ? "search" : "people"}
          title={t("loyalty.admin.customersEmpty")}
        />
      ) : (
        <ul className="space-y-2">
          {rows.map((row) => {
            const name = row.full_name || t("loyalty.admin.customerUnnamed");
            const position = tierFor(row.lifetime_points, program.tiers);
            const style = tierStyleKey(position.index, program.tiers.length);
            return (
              <li
                key={row.user_id}
                className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3"
              >
                <PersonAvatar name={name} seed={row.user_id} size="sm" />
                <div className="min-w-0 flex-1 basis-36">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <p className="truncate text-sm font-bold">{name}</p>
                    <TierBadge tier={style} name={position.tier.name} size="sm" />
                  </div>
                  {position.next ? (
                    <div className="mt-1.5 flex items-center gap-2">
                      <span
                        aria-hidden
                        className="relative h-1.5 w-20 shrink-0 overflow-hidden rounded-full bg-muted"
                      >
                        <span
                          className="absolute inset-y-0 left-0 rounded-full bg-[color:var(--gold)]"
                          style={{ width: `${Math.max(6, position.progress)}%` }}
                        />
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {t("loyalty.admin.toNext", {
                          n: position.pointsToNext,
                          name: position.next.name,
                        })}
                      </span>
                    </div>
                  ) : (
                    <p className="mt-1 text-xs text-muted-foreground">
                      {t("loyalty.admin.topLevel")}
                    </p>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-lg font-extrabold tabular-nums leading-none">{row.points}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {t("loyalty.admin.toUse", { total: row.lifetime_points })}
                  </p>
                </div>
                {canAdjust && row.user_id !== myId && (
                  <button
                    type="button"
                    onClick={() => setAdjusting(row)}
                    aria-label={t("loyalty.admin.adjustOf", { name })}
                    className="inline-flex min-h-11 shrink-0 items-center gap-1.5 rounded-xl border border-border px-3 text-xs font-bold transition hover:border-primary/40"
                  >
                    <PlusCircle className="size-4" aria-hidden />
                    {t("loyalty.admin.adjust")}
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      )}
      {adjusting && (
        <AdjustDialog
          shopId={shopId}
          customer={adjusting}
          onClose={() => setAdjusting(null)}
          onDone={async () => {
            setAdjusting(null);
            await load(search.trim());
          }}
        />
      )}
    </section>
  );
}

function AdjustDialog({
  shopId,
  customer,
  onClose,
  onDone,
}: {
  shopId: string;
  customer: CustomerRow;
  onClose: () => void;
  onDone: () => Promise<void>;
}) {
  const { t } = useI18n();
  const [direction, setDirection] = useState<"add" | "remove">("add");
  const [amount, setAmount] = useState("10");
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const value = clampInt(amount, 1, 1000);
  const delta = direction === "add" ? value : -value;
  const result = customer.points + delta;
  const reasonLength = reason.trim().length;
  const invalid = result < 0 || reasonLength < 10;

  async function save(event: FormEvent) {
    event.preventDefault();
    if (invalid) return;
    setSaving(true);
    setError(null);
    const { error: rpcError } = await supabase.rpc("adjust_loyalty_points", {
      p_shop_id: shopId,
      p_user_id: customer.user_id,
      p_delta: delta,
      p_reason: reason.trim(),
    });
    setSaving(false);
    if (rpcError) {
      setError(friendlyAuthError(rpcError, t("loyalty.admin.saveError")));
      return;
    }
    toast.success(t("loyalty.admin.adjustDone"));
    await onDone();
  }

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogTitle>
          {t("loyalty.admin.adjustTitle", {
            name: customer.full_name || t("loyalty.admin.customerUnnamed"),
          })}
        </DialogTitle>
        <DialogDescription>{t("loyalty.admin.adjustHint")}</DialogDescription>
        <DialogScrollArea>
          <form id="adjust-form" onSubmit={save} className="space-y-3">
            <div className="grid grid-cols-2 gap-2" role="radiogroup">
              {(["add", "remove"] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  role="radio"
                  aria-checked={direction === option}
                  onClick={() => setDirection(option)}
                  className={`flex min-h-11 items-center justify-center gap-2 rounded-xl border text-sm font-bold ${
                    direction === option
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border"
                  }`}
                >
                  {option === "add" ? (
                    <Plus className="size-4" aria-hidden />
                  ) : (
                    <Minus className="size-4" aria-hidden />
                  )}
                  {t(option === "add" ? "loyalty.admin.adjustAdd" : "loyalty.admin.adjustRemove")}
                </button>
              ))}
            </div>
            <ChoiceChips
              label={t("loyalty.admin.adjustAmount")}
              options={[10, 50, 100].map((n) => ({
                value: n,
                label: `${direction === "add" ? "+" : "−"}${n}`,
              }))}
              value={value}
              onChange={(next) => setAmount(String(next))}
              other={{ min: 1, max: 1000, unit: t("points.short") }}
            />
            <Field
              label={t("loyalty.admin.adjustReason")}
              hint={t("loyalty.admin.adjustReasonHint")}
            >
              {(props) => (
                <div className="space-y-1">
                  <textarea
                    {...props}
                    value={reason}
                    required
                    minLength={10}
                    maxLength={240}
                    rows={2}
                    placeholder={t("loyalty.admin.adjustReasonPlaceholder")}
                    onChange={(e) => setReason(e.target.value)}
                    className={`${fieldClass} text-base sm:text-sm`}
                  />
                  <FieldMessage tone={reasonLength >= 10 ? "success" : "hint"}>
                    {reasonLength >= 10
                      ? t("loyalty.admin.reasonOk")
                      : t("loyalty.admin.reasonCount", { n: reasonLength, min: 10 })}
                  </FieldMessage>
                </div>
              )}
            </Field>
            <div aria-live="polite">
              {result < 0 ? (
                <Notice tone="danger" title={t("loyalty.admin.adjustNegative")} />
              ) : (
                <DetailList
                  items={[
                    {
                      label: t("loyalty.admin.adjustBalance"),
                      icon: Star,
                      previous: customer.points,
                      value: (
                        <span className="text-base font-extrabold tabular-nums">{result}</span>
                      ),
                      delta: {
                        label: `${delta > 0 ? "+" : "−"}${Math.abs(delta)}`,
                        tone: delta > 0 ? "success" : "danger",
                      },
                    },
                  ]}
                />
              )}
            </div>
            {error && <Notice tone="danger" title={error} />}
          </form>
        </DialogScrollArea>
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={onClose}
            className="min-h-11 rounded-xl border border-border px-4 text-sm font-bold"
          >
            {t("loyalty.admin.cancel")}
          </button>
          <button
            type="submit"
            form="adjust-form"
            disabled={saving || invalid}
            className="action-button action-confirm"
          >
            {saving && <Loader2 className="size-4 animate-spin" aria-hidden />}
            {t("loyalty.admin.adjustSave")}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
