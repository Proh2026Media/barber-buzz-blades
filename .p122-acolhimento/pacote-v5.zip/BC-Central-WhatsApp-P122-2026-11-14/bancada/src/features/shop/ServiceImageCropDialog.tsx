import { useEffect, useId, useMemo, useRef, useState } from "react";
import { Check, Crop, Move, RotateCcw, ZoomIn } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { useI18n } from "@/lib/i18n";
import { SERVICE_IMAGE_CROP_SIZE } from "@/lib/shop/service-image";
import { getSquareCropRect, initialCropOffset } from "@/lib/shop/service-image-crop";

type Offset = { x: number; y: number };

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

/** Acima disso, o PNG gerado pelo Safari é trocado por JPEG (o armazenamento aceita até 2 MB). */
const CROP_PNG_MAX_BYTES = 1_800_000;

export function ServiceImageCropDialog({
  file,
  onCancel,
  onConfirm,
  title,
  description,
  imageAlt,
  outputName = "servico-1x1.webp",
  focusY = 0.5,
  preview,
}: {
  file: File | null;
  onCancel: () => void;
  onConfirm: (file: File) => Promise<void> | void;
  title?: string;
  description?: string;
  imageAlt?: string;
  outputName?: string;
  /** Altura (0 = topo, 0,5 = meio) que o corte automático deixa no centro do quadro. */
  focusY?: number;
  /**
   * Miniatura "Assim fica" ao lado do zoom: quadrado do serviço ou foto redonda do profissional.
   * Com ela, a frase de apoio da janela fica só para leitor de tela (a imagem já explica).
   */
  preview?: "square" | "round";
}) {
  const { t } = useI18n();
  const imageUrl = useMemo(() => (file ? URL.createObjectURL(file) : ""), [file]);
  const imageRef = useRef<HTMLImageElement>(null);
  // O quadro só existe depois que a janela monta; a medida segue o elemento, não o arquivo.
  const [viewportEl, setViewportEl] = useState<HTMLDivElement | null>(null);
  const autoFrameRef = useRef(false);
  const dragRef = useRef<{ pointerId: number; x: number; y: number; offset: Offset } | null>(null);
  const zoomLabelId = useId();
  const [naturalSize, setNaturalSize] = useState({ width: 1, height: 1 });
  const [viewportSize, setViewportSize] = useState(300);
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState<Offset>({ x: 0, y: 0 });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => () => URL.revokeObjectURL(imageUrl), [imageUrl]);

  useEffect(() => {
    if (!file) return;
    setZoom(1);
    setOffset({ x: 0, y: 0 });
    setError(null);
  }, [file]);

  useEffect(() => {
    const viewport = viewportEl;
    if (!viewport) return;
    const update = () => setViewportSize(viewport.clientWidth || 300);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(viewport);
    return () => observer.disconnect();
  }, [viewportEl]);

  const geometry = useMemo(() => {
    const baseScale = Math.max(viewportSize / naturalSize.width, viewportSize / naturalSize.height);
    const width = naturalSize.width * baseScale * zoom;
    const height = naturalSize.height * baseScale * zoom;
    return {
      width,
      height,
      maxX: Math.max(0, (width - viewportSize) / 2),
      maxY: Math.max(0, (height - viewportSize) / 2),
    };
  }, [naturalSize, viewportSize, zoom]);

  useEffect(() => {
    if (!autoFrameRef.current) return;
    setOffset(
      initialCropOffset({
        naturalWidth: naturalSize.width,
        naturalHeight: naturalSize.height,
        viewportSize,
        focusY,
      }),
    );
  }, [naturalSize, viewportSize, focusY]);

  const moveTo = (next: Offset) => {
    autoFrameRef.current = false;
    setOffset({
      x: clamp(next.x, -geometry.maxX, geometry.maxX),
      y: clamp(next.y, -geometry.maxY, geometry.maxY),
    });
  };

  useEffect(() => {
    setOffset((current) => ({
      x: clamp(current.x, -geometry.maxX, geometry.maxX),
      y: clamp(current.y, -geometry.maxY, geometry.maxY),
    }));
  }, [geometry.maxX, geometry.maxY]);

  async function confirmCrop() {
    const image = imageRef.current;
    if (!image || !file) return;
    setSaving(true);
    setError(null);
    try {
      const crop = getSquareCropRect({
        naturalWidth: naturalSize.width,
        naturalHeight: naturalSize.height,
        viewportSize,
        zoom,
        offsetX: offset.x,
        offsetY: offset.y,
      });
      const canvas = document.createElement("canvas");
      canvas.width = SERVICE_IMAGE_CROP_SIZE;
      canvas.height = SERVICE_IMAGE_CROP_SIZE;
      const context = canvas.getContext("2d");
      if (!context) throw new Error(t("brand.crop.errorCanvas"));
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = "high";
      context.drawImage(
        image,
        crop.x,
        crop.y,
        crop.size,
        crop.size,
        0,
        0,
        SERVICE_IMAGE_CROP_SIZE,
        SERVICE_IMAGE_CROP_SIZE,
      );
      const encode = (target: HTMLCanvasElement, type: string, quality: number) =>
        new Promise<Blob>((resolve, reject) =>
          target.toBlob(
            (result) => (result ? resolve(result) : reject(new Error(t("brand.crop.errorFinish")))),
            type,
            quality,
          ),
        );
      let blob = await encode(canvas, "image/webp", 0.9);
      // Safari/iPhone não gera WebP no canvas e devolve PNG sem perda, que pode passar
      // do limite de 2 MB do armazenamento. Nesse caso, gera JPEG sobre fundo branco.
      if (blob.type !== "image/webp" && blob.size > CROP_PNG_MAX_BYTES) {
        const flat = document.createElement("canvas");
        flat.width = canvas.width;
        flat.height = canvas.height;
        const flatContext = flat.getContext("2d");
        if (!flatContext) throw new Error(t("brand.crop.errorCanvas"));
        flatContext.fillStyle = "#ffffff";
        flatContext.fillRect(0, 0, flat.width, flat.height);
        flatContext.drawImage(canvas, 0, 0);
        blob = await encode(flat, "image/jpeg", 0.85);
      }
      const extension =
        blob.type === "image/jpeg" ? "jpg" : blob.type === "image/png" ? "png" : "webp";
      const finalName = outputName.replace(/\.[a-z0-9]+$/i, "") + "." + extension;
      await onConfirm(new File([blob], finalName, { type: blob.type }));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : t("brand.crop.errorGeneric"));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={Boolean(file)} onOpenChange={(open) => !open && !saving && onCancel()}>
      <DialogContent className="w-[calc(100vw-1.5rem)] max-w-md overflow-hidden rounded-3xl p-0 sm:rounded-3xl">
        <div className="space-y-4 p-5 sm:p-6">
          <div className="pr-8">
            <DialogTitle className="flex items-center gap-2">
              <Crop className="size-5 text-gold" /> {title ?? t("brand.crop.title")}
            </DialogTitle>
            <DialogDescription className={preview ? "sr-only" : "mt-1"}>
              {description ?? t("brand.crop.description")}
            </DialogDescription>
          </div>

          <div
            ref={setViewportEl}
            className="service-crop-viewport"
            tabIndex={0}
            role="application"
            aria-label={t("brand.crop.areaAria")}
            onKeyDown={(event) => {
              const distance = event.shiftKey ? 16 : 4;
              const movements: Record<string, Offset> = {
                ArrowLeft: { x: offset.x - distance, y: offset.y },
                ArrowRight: { x: offset.x + distance, y: offset.y },
                ArrowUp: { x: offset.x, y: offset.y - distance },
                ArrowDown: { x: offset.x, y: offset.y + distance },
              };
              if (movements[event.key]) {
                event.preventDefault();
                moveTo(movements[event.key]);
              }
            }}
            onPointerDown={(event) => {
              if (saving) return;
              event.currentTarget.setPointerCapture(event.pointerId);
              dragRef.current = {
                pointerId: event.pointerId,
                x: event.clientX,
                y: event.clientY,
                offset,
              };
            }}
            onPointerMove={(event) => {
              const drag = dragRef.current;
              if (!drag || drag.pointerId !== event.pointerId) return;
              moveTo({
                x: drag.offset.x + event.clientX - drag.x,
                y: drag.offset.y + event.clientY - drag.y,
              });
            }}
            onPointerUp={(event) => {
              if (dragRef.current?.pointerId === event.pointerId) dragRef.current = null;
            }}
            onPointerCancel={() => {
              dragRef.current = null;
            }}
          >
            {imageUrl && (
              <img
                ref={imageRef}
                src={imageUrl}
                alt={imageAlt ?? t("brand.crop.alt")}
                draggable={false}
                onLoad={(event) => {
                  const natural = {
                    width: event.currentTarget.naturalWidth,
                    height: event.currentTarget.naturalHeight,
                  };
                  autoFrameRef.current = true;
                  setNaturalSize(natural);
                }}
                style={{
                  width: geometry.width,
                  height: geometry.height,
                  transform: `translate(-50%, -50%) translate(${offset.x}px, ${offset.y}px)`,
                }}
              />
            )}
            <div className="service-crop-grid" aria-hidden />
            <span className="service-crop-hint" aria-hidden>
              <Move className="size-4" /> {t("brand.crop.dragHint")}
            </span>
          </div>

          <div className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3">
            {preview && imageUrl && (
              <figure className="flex shrink-0 flex-col items-center gap-1">
                <span
                  className={`relative block size-14 overflow-hidden bg-muted ${preview === "round" ? "rounded-full" : "rounded-xl"}`}
                >
                  <img
                    src={imageUrl}
                    alt=""
                    draggable={false}
                    className="pointer-events-none absolute left-1/2 top-1/2 max-w-none"
                    style={{
                      width: (geometry.width * 56) / viewportSize,
                      height: (geometry.height * 56) / viewportSize,
                      transform: `translate(-50%, -50%) translate(${(offset.x * 56) / viewportSize}px, ${(offset.y * 56) / viewportSize}px)`,
                    }}
                  />
                </span>
                <figcaption className="text-[11px] font-semibold text-muted-foreground">
                  {t("catalog.crop.preview")}
                </figcaption>
              </figure>
            )}
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-3">
                <label id={zoomLabelId} className="flex items-center gap-2 text-sm font-semibold">
                  <ZoomIn className="size-4 text-gold" /> {t("brand.crop.zoom")}
                </label>
                <output className="text-xs font-bold tabular-nums text-muted-foreground">
                  {Math.round(zoom * 100)}%
                </output>
              </div>
              <Slider
                className="mt-1"
                min={1}
                max={3}
                step={0.01}
                value={[zoom]}
                aria-labelledby={zoomLabelId}
                aria-valuetext={t("brand.crop.zoomValue", { value: Math.round(zoom * 100) })}
                onValueChange={([value]) => {
                  autoFrameRef.current = false;
                  setZoom(value ?? 1);
                }}
              />
              <button
                type="button"
                className="mt-1 flex min-h-11 items-center gap-2 text-xs font-semibold text-muted-foreground"
                onClick={() => {
                  setZoom(1);
                  autoFrameRef.current = true;
                  setOffset(
                    initialCropOffset({
                      naturalWidth: naturalSize.width,
                      naturalHeight: naturalSize.height,
                      viewportSize,
                      focusY,
                    }),
                  );
                }}
              >
                <RotateCcw className="size-4" /> {t("brand.crop.recenter")}
              </button>
            </div>
          </div>

          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              className="min-h-11 rounded-xl border border-border bg-background px-3 text-sm font-semibold"
              disabled={saving}
              onClick={onCancel}
            >
              {t("brand.crop.back")}
            </button>
            <button
              type="button"
              className="action-button action-success"
              disabled={saving}
              onClick={() => void confirmCrop()}
            >
              <Check className="size-4" /> {saving ? t("brand.save.saving") : t("brand.crop.use")}
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
