export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5";
  };
  public: {
    Tables: {
      barbershops: {
        Row: {
          id: string;
          name: string;
          slug: string;
          status: Database["public"]["Enums"]["barbershop_status"];
          timezone: string;
          custom_domain: string | null;
          custom_domain_status: "none" | "pending_dns" | "active" | "error";
          domain_verify_token: string | null;
          domain_verified_at: string | null;
          domain_last_error: string | null;
          society_intent?: string | null;
          founded_by_user_id?: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          slug?: string;
          status?: Database["public"]["Enums"]["barbershop_status"];
          timezone?: string;
          custom_domain?: string | null;
          custom_domain_status?: "none" | "pending_dns" | "active" | "error";
          domain_verify_token?: string | null;
          domain_verified_at?: string | null;
          domain_last_error?: string | null;
          society_intent?: string | null;
          founded_by_user_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          slug?: string;
          status?: Database["public"]["Enums"]["barbershop_status"];
          timezone?: string;
          custom_domain?: string | null;
          custom_domain_status?: "none" | "pending_dns" | "active" | "error";
          domain_verify_token?: string | null;
          domain_verified_at?: string | null;
          domain_last_error?: string | null;
          society_intent?: string | null;
          founded_by_user_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      barbershop_settings: {
        Row: {
          barbershop_id: string;
          display_name: string | null;
          logo_url: string | null;
          logo_background_color: string | null;
          login_image_url: string | null;
          login_layout: string;
          font_family: string;
          custom_font_url: string | null;
          custom_font_name: string | null;
          custom_font_faces: Json;
          font_scope: string;
          header_font_weight: number;
          header_font_style: string;
          corner_style: string;
          floating_chrome: boolean;
          primary_color: string;
          accent_color: string;
          tagline: string;
          booking_instructions: string;
          booking_horizon_days: number;
          survey_program_enabled: boolean;
          sports_enabled: boolean;
          loyalty_enabled: boolean;
          landing: Json;
          waiting_enabled: boolean;
          waiting_cutoff_minutes: number;
          staff_assignment_mode?: string;
          slot_mode: string;
          slot_step_minutes: number;
          prep_minutes: number;
          min_lead_minutes: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          barbershop_id: string;
          display_name?: string | null;
          logo_url?: string | null;
          logo_background_color?: string | null;
          login_image_url?: string | null;
          login_layout?: string;
          font_family?: string;
          custom_font_url?: string | null;
          custom_font_name?: string | null;
          custom_font_faces?: Json;
          font_scope?: string;
          header_font_weight?: number;
          header_font_style?: string;
          corner_style?: string;
          floating_chrome?: boolean;
          primary_color?: string;
          accent_color?: string;
          tagline?: string;
          booking_instructions?: string;
          booking_horizon_days?: number;
          survey_program_enabled?: boolean;
          sports_enabled?: boolean;
          loyalty_enabled?: boolean;
          landing?: Json;
          waiting_enabled?: boolean;
          waiting_cutoff_minutes?: number;
          staff_assignment_mode?: string;
          slot_mode?: string;
          slot_step_minutes?: number;
          prep_minutes?: number;
          min_lead_minutes?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          barbershop_id?: string;
          display_name?: string | null;
          logo_url?: string | null;
          logo_background_color?: string | null;
          login_image_url?: string | null;
          login_layout?: string;
          font_family?: string;
          custom_font_url?: string | null;
          custom_font_name?: string | null;
          custom_font_faces?: Json;
          font_scope?: string;
          header_font_weight?: number;
          header_font_style?: string;
          corner_style?: string;
          floating_chrome?: boolean;
          primary_color?: string;
          accent_color?: string;
          tagline?: string;
          booking_instructions?: string;
          booking_horizon_days?: number;
          survey_program_enabled?: boolean;
          sports_enabled?: boolean;
          loyalty_enabled?: boolean;
          landing?: Json;
          waiting_enabled?: boolean;
          waiting_cutoff_minutes?: number;
          staff_assignment_mode?: string;
          slot_mode?: string;
          slot_step_minutes?: number;
          prep_minutes?: number;
          min_lead_minutes?: number;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "barbershop_settings_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: true;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          id: string;
          full_name: string | null;
          avatar_url: string | null;
          whatsapp_e164: string | null;
          whatsapp_opt_in_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name?: string | null;
          avatar_url?: string | null;
          whatsapp_e164?: string | null;
          whatsapp_opt_in_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          whatsapp_e164?: string | null;
          whatsapp_opt_in_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      memberships: {
        Row: {
          id: string;
          user_id: string;
          barbershop_id: string | null;
          role: Database["public"]["Enums"]["app_role"];
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          barbershop_id?: string | null;
          role: Database["public"]["Enums"]["app_role"];
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          barbershop_id?: string | null;
          role?: Database["public"]["Enums"]["app_role"];
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "memberships_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      shop_members: {
        Row: {
          id: string;
          barbershop_id: string;
          user_id: string;
          staff_id: string;
          role: Database["public"]["Enums"]["shop_member_role"];
          ownership_percent: number | null;
          active: boolean;
          created_at: string;
          updated_at: string;
          /** Nulo: a janela de boas-vindas ainda não foi vista (vínculo novo ou papel novo). */
          welcome_seen_at?: string | null;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          user_id: string;
          staff_id: string;
          role: Database["public"]["Enums"]["shop_member_role"];
          ownership_percent?: number | null;
          active?: boolean;
          created_at?: string;
          updated_at?: string;
          welcome_seen_at?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["shop_members"]["Insert"]>;
        Relationships: [];
      };
      shop_invite_links: {
        Row: {
          id: string;
          token_hash: string;
          barbershop_id: string;
          user_id: string;
          role: Database["public"]["Enums"]["shop_member_role"];
          created_by: string | null;
          created_at: string;
          expires_at: string;
          last_used_at: string | null;
          use_count: number;
        };
        Insert: {
          id?: string;
          token_hash: string;
          barbershop_id: string;
          user_id: string;
          role: Database["public"]["Enums"]["shop_member_role"];
          created_by?: string | null;
          created_at?: string;
          expires_at?: string;
          last_used_at?: string | null;
          use_count?: number;
        };
        Update: Partial<Database["public"]["Tables"]["shop_invite_links"]["Insert"]>;
        Relationships: [];
      };
      shop_change_requests: {
        Row: {
          id: string;
          barbershop_id: string;
          requested_by: string;
          approved_by: string | null;
          kind: string;
          payload: Json;
          status: Database["public"]["Enums"]["shop_change_status"];
          decision_note: string | null;
          created_at: string;
          decided_at: string | null;
          applied_at: string | null;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          requested_by: string;
          approved_by?: string | null;
          kind: string;
          payload: Json;
          status?: Database["public"]["Enums"]["shop_change_status"];
          decision_note?: string | null;
          created_at?: string;
          decided_at?: string | null;
          applied_at?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["shop_change_requests"]["Insert"]>;
        Relationships: [];
      };
      shop_change_approvals: {
        Row: {
          request_id: string;
          user_id: string;
          approved: boolean;
          note: string | null;
          decided_at: string;
        };
        Insert: {
          request_id: string;
          user_id: string;
          approved: boolean;
          note?: string | null;
          decided_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["shop_change_approvals"]["Insert"]>;
        Relationships: [];
      };
      staff_services: {
        Row: {
          id: string;
          barbershop_id: string;
          staff_id: string;
          service_id: string;
          display_name: string | null;
          duration_minutes: number;
          price_cents: number;
          active: boolean;
          icon: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          staff_id: string;
          service_id: string;
          display_name?: string | null;
          duration_minutes: number;
          price_cents: number;
          active?: boolean;
          icon?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["staff_services"]["Insert"]>;
        Relationships: [];
      };
      services: {
        Row: {
          id: string;
          barbershop_id: string;
          name: string;
          duration_minutes: number;
          price_cents: number;
          active: boolean;
          icon: string | null;
          prep_minutes: number | null;
          description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          name: string;
          duration_minutes?: number;
          price_cents?: number;
          active?: boolean;
          icon?: string | null;
          prep_minutes?: number | null;
          description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          name?: string;
          duration_minutes?: number;
          price_cents?: number;
          active?: boolean;
          icon?: string | null;
          prep_minutes?: number | null;
          description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "services_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      staff: {
        Row: {
          id: string;
          barbershop_id: string;
          display_name: string;
          active: boolean;
          user_id: string | null;
          booking_slug: string | null;
          bio?: string | null;
          avatar_url?: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          display_name: string;
          active?: boolean;
          user_id?: string | null;
          booking_slug?: string | null;
          bio?: string | null;
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          display_name?: string;
          active?: boolean;
          user_id?: string | null;
          booking_slug?: string | null;
          bio?: string | null;
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "staff_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      appointments: {
        Row: {
          id: string;
          barbershop_id: string;
          /** Nulo: cliente do balcão (sem conta, ver `shop_client_id`) ou conta excluída. */
          customer_id: string | null;
          service_id: string;
          staff_id: string;
          starts_at: string;
          ends_at: string;
          status: Database["public"]["Enums"]["appointment_status"];
          booked_price_cents: number | null;
          public_token: string;
          series_id: string | null;
          created_at: string;
          updated_at: string;
          /** Migration 20261016130000 (ausente antes dela): cliente do balcão. */
          shop_client_id?: string | null;
          /** Migration 20261016130000 (ausente antes dela): quem da equipe marcou. */
          booked_by?: string | null;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          customer_id?: string | null;
          service_id: string;
          staff_id: string;
          starts_at: string;
          ends_at: string;
          status?: Database["public"]["Enums"]["appointment_status"];
          booked_price_cents?: number | null;
          public_token?: string;
          series_id?: string | null;
          created_at?: string;
          updated_at?: string;
          shop_client_id?: string | null;
          booked_by?: string | null;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          customer_id?: string | null;
          service_id?: string;
          staff_id?: string;
          starts_at?: string;
          ends_at?: string;
          status?: Database["public"]["Enums"]["appointment_status"];
          booked_price_cents?: number | null;
          public_token?: string;
          series_id?: string | null;
          created_at?: string;
          updated_at?: string;
          shop_client_id?: string | null;
          booked_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "appointments_shop_client_id_fkey";
            columns: ["shop_client_id"];
            isOneToOne: false;
            referencedRelation: "shop_clients";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "appointments_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "appointments_service_id_fkey";
            columns: ["service_id"];
            isOneToOne: false;
            referencedRelation: "services";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "appointments_staff_id_fkey";
            columns: ["staff_id"];
            isOneToOne: false;
            referencedRelation: "staff";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "appointments_customer_id_fkey";
            columns: ["customer_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      shop_clients: {
        Row: {
          id: string;
          barbershop_id: string;
          profile_id: string | null;
          full_name: string | null;
          whatsapp_e164: string | null;
          nickname: string | null;
          notify_whatsapp: boolean;
          created_by: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          profile_id?: string | null;
          full_name?: string | null;
          whatsapp_e164?: string | null;
          nickname?: string | null;
          notify_whatsapp?: boolean;
          created_by?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          profile_id?: string | null;
          full_name?: string | null;
          whatsapp_e164?: string | null;
          nickname?: string | null;
          notify_whatsapp?: boolean;
          created_by?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      availability_signals: {
        Row: {
          id: number;
          barbershop_id: string;
          staff_id: string | null;
          changed_at: string;
        };
        Insert: {
          id?: never;
          barbershop_id: string;
          staff_id?: string | null;
          changed_at?: string;
        };
        Update: {
          id?: never;
          barbershop_id?: string;
          staff_id?: string | null;
          changed_at?: string;
        };
        Relationships: [];
      };
      business_hours: {
        Row: {
          id: string;
          barbershop_id: string;
          weekday: number;
          is_open: boolean;
          opens_at: string;
          closes_at: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          weekday: number;
          is_open?: boolean;
          opens_at?: string;
          closes_at?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          weekday?: number;
          is_open?: boolean;
          opens_at?: string;
          closes_at?: string;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "business_hours_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      /** Privada: nenhuma leitura/gravação direta pelo navegador. */
      mercado_pago_connections: {
        Row: {
          id: string;
          barbershop_id: string;
          receiver_scope: string;
          professional_user_id: string | null;
          staff_id: string | null;
          status: string;
          connection_revision: number;
          collector_id: string | null;
          live_mode: boolean | null;
          access_token_ciphertext: string | null;
          refresh_token_ciphertext: string | null;
          token_expires_at: string | null;
          connected_at: string | null;
          connected_by: string | null;
          disconnected_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          barbershop_id: string;
          receiver_scope: string;
          professional_user_id?: string | null;
          staff_id?: string | null;
          status?: string;
          connection_revision?: number;
          collector_id?: string | null;
          live_mode?: boolean | null;
          access_token_ciphertext?: string | null;
          refresh_token_ciphertext?: string | null;
          token_expires_at?: string | null;
          connected_at?: string | null;
          connected_by?: string | null;
          disconnected_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["mercado_pago_connections"]["Insert"]>;
        Relationships: [
          {
            foreignKeyName: "mercado_pago_connections_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      /** Privada: nonce somente como SHA-256 e PKCE cifrado até o consumo. */
      mercado_pago_oauth_requests: {
        Row: {
          id: string;
          barbershop_id: string;
          actor_id: string;
          connection_id: string;
          receiver_scope: string;
          staff_id: string | null;
          state_hash: string;
          environment: string;
          verifier_ciphertext: string | null;
          connection_revision: number;
          created_at: string;
          expires_at: string;
          consumed_at: string | null;
          finished_at: string | null;
          revoked_at: string | null;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          actor_id: string;
          connection_id: string;
          receiver_scope: string;
          staff_id?: string | null;
          state_hash: string;
          environment: string;
          verifier_ciphertext?: string | null;
          connection_revision: number;
          created_at: string;
          expires_at: string;
          consumed_at?: string | null;
          finished_at?: string | null;
          revoked_at?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["mercado_pago_oauth_requests"]["Insert"]>;
        Relationships: [
          {
            foreignKeyName: "mercado_pago_oauth_requests_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      shop_weekly_break_versions: {
        Row: { barbershop_id: string; revision: number };
        Insert: { barbershop_id: string; revision?: number };
        Update: { barbershop_id?: string; revision?: number };
        Relationships: [
          {
            foreignKeyName: "shop_weekly_break_versions_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: true;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      availability_block_rules: {
        Row: {
          id: string;
          barbershop_id: string;
          staff_id: string | null;
          /** 0 = domingo … 6 = sábado. */
          weekdays: number[];
          start_time: string;
          end_time: string;
          reason: string | null;
          created_by: string | null;
          created_at: string;
          materialized_until: string | null;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          staff_id?: string | null;
          weekdays: number[];
          start_time: string;
          end_time: string;
          reason?: string | null;
          created_by?: string | null;
          created_at?: string;
          materialized_until?: string | null;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          staff_id?: string | null;
          weekdays?: number[];
          start_time?: string;
          end_time?: string;
          reason?: string | null;
          created_by?: string | null;
          created_at?: string;
          materialized_until?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "availability_block_rules_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "availability_block_rules_staff_id_fkey";
            columns: ["staff_id"];
            isOneToOne: false;
            referencedRelation: "staff";
            referencedColumns: ["id"];
          },
        ];
      };
      availability_blocks: {
        Row: {
          id: string;
          barbershop_id: string;
          staff_id: string | null;
          starts_at: string;
          ends_at: string;
          reason: string | null;
          created_at: string;
          /** Pausa fixa semanal que gerou o bloqueio (nulo = bloqueio avulso). */
          rule_id?: string | null;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          staff_id?: string | null;
          starts_at: string;
          ends_at: string;
          reason?: string | null;
          created_at?: string;
          rule_id?: string | null;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          staff_id?: string | null;
          starts_at?: string;
          ends_at?: string;
          reason?: string | null;
          created_at?: string;
          rule_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "availability_blocks_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "availability_blocks_staff_id_fkey";
            columns: ["staff_id"];
            isOneToOne: false;
            referencedRelation: "staff";
            referencedColumns: ["id"];
          },
        ];
      };
      loyalty_accounts: {
        Row: {
          user_id: string;
          barbershop_id: string;
          points: number;
          lifetime_points: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          barbershop_id: string;
          points?: number;
          lifetime_points?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          user_id?: string;
          barbershop_id?: string;
          points?: number;
          lifetime_points?: number;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "loyalty_accounts_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      loyalty_programs: {
        Row: {
          barbershop_id: string;
          mode: string;
          points_per_visit: number;
          welcome_bonus: number;
          tiers: Json;
          version: number;
          updated_by: string | null;
          updated_at: string;
        };
        Insert: {
          barbershop_id: string;
          mode?: string;
          points_per_visit?: number;
          welcome_bonus?: number;
          tiers?: Json;
          version?: number;
          updated_by?: string | null;
          updated_at?: string;
        };
        Update: {
          barbershop_id?: string;
          mode?: string;
          points_per_visit?: number;
          welcome_bonus?: number;
          tiers?: Json;
          version?: number;
          updated_by?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
      loyalty_rewards: {
        Row: {
          id: string;
          barbershop_id: string;
          name: string;
          description: string;
          cost_points: number;
          active: boolean;
          sort_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          name: string;
          description?: string;
          cost_points: number;
          active?: boolean;
          sort_order?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          name?: string;
          description?: string;
          cost_points?: number;
          active?: boolean;
          sort_order?: number;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      loyalty_redemptions: {
        Row: {
          id: string;
          barbershop_id: string;
          user_id: string;
          reward_id: string | null;
          reward_name: string;
          cost_points: number;
          status: string;
          created_at: string;
          expires_at: string;
          resolved_at: string | null;
          resolved_by: string | null;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          user_id: string;
          reward_id?: string | null;
          reward_name: string;
          cost_points: number;
          status?: string;
          created_at?: string;
          expires_at?: string;
          resolved_at?: string | null;
          resolved_by?: string | null;
        };
        Update: {
          id?: string;
          barbershop_id?: string;
          user_id?: string;
          reward_id?: string | null;
          reward_name?: string;
          cost_points?: number;
          status?: string;
          created_at?: string;
          expires_at?: string;
          resolved_at?: string | null;
          resolved_by?: string | null;
        };
        Relationships: [];
      };
      loyalty_ledger: {
        Row: {
          id: string;
          user_id: string;
          barbershop_id: string;
          delta: number;
          reason: string;
          appointment_id: string | null;
          program_version: number | null;
          note: string | null;
          actor_id: string | null;
          redemption_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          barbershop_id: string;
          delta: number;
          reason: string;
          appointment_id?: string | null;
          program_version?: number | null;
          note?: string | null;
          actor_id?: string | null;
          redemption_id?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          barbershop_id?: string;
          delta?: number;
          reason?: string;
          appointment_id?: string | null;
          program_version?: number | null;
          note?: string | null;
          actor_id?: string | null;
          redemption_id?: string | null;
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "loyalty_ledger_appointment_id_fkey";
            columns: ["appointment_id"];
            isOneToOne: false;
            referencedRelation: "appointments";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "loyalty_ledger_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      whatsapp_channels: {
        Row: {
          id: string;
          staff_id: string | null;
          label: string;
          routing_version: number;
          backup_instance_name: string | null;
          delivery_mode: string;
          delivery_reason: string | null;
          return_notice_enabled: boolean;
          barbershop_id: string | null;
          instance_name: string;
          status: Database["public"]["Enums"]["whatsapp_channel_status"];
          display_phone: string | null;
          enabled: boolean;
          notify_booking: boolean;
          notify_reminder: boolean;
          reminder_hours_before: number;
          last_error: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          staff_id?: string | null;
          label?: string;
          routing_version?: number;
          backup_instance_name?: string | null;
          delivery_mode?: string;
          delivery_reason?: string | null;
          return_notice_enabled?: boolean;
          barbershop_id: string | null;
          instance_name: string;
          status?: Database["public"]["Enums"]["whatsapp_channel_status"];
          display_phone?: string | null;
          enabled?: boolean;
          notify_booking?: boolean;
          notify_reminder?: boolean;
          reminder_hours_before?: number;
          last_error?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["whatsapp_channels"]["Insert"]>;
        Relationships: [];
      };
      whatsapp_outbox: {
        Row: {
          id: string;
          barbershop_id: string;
          to_e164: string;
          template_key: string;
          body: string;
          payload: Json;
          status: Database["public"]["Enums"]["whatsapp_outbox_status"];
          provider_message_id: string | null;
          error: string | null;
          attempts: number;
          dedupe_key: string;
          scheduled_at: string;
          sent_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          to_e164: string;
          template_key: string;
          body: string;
          payload?: Json;
          status?: Database["public"]["Enums"]["whatsapp_outbox_status"];
          provider_message_id?: string | null;
          error?: string | null;
          attempts?: number;
          dedupe_key: string;
          scheduled_at?: string;
          sent_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["whatsapp_outbox"]["Insert"]>;
        Relationships: [];
      };
      whatsapp_message_templates: {
        Row: {
          barbershop_id: string;
          template_key: string;
          body: string;
          updated_at: string;
        };
        Insert: {
          barbershop_id: string;
          template_key: string;
          body: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["whatsapp_message_templates"]["Insert"]>;
        Relationships: [
          {
            foreignKeyName: "whatsapp_message_templates_barbershop_id_fkey";
            columns: ["barbershop_id"];
            isOneToOne: false;
            referencedRelation: "barbershops";
            referencedColumns: ["id"];
          },
        ];
      };
      email_outbox: {
        Row: {
          id: string;
          barbershop_id: string;
          to_email: string;
          template_key: string;
          subject: string;
          body: string;
          payload: Json;
          status: Database["public"]["Enums"]["email_outbox_status"];
          error: string | null;
          attempts: number;
          dedupe_key: string;
          scheduled_at: string;
          sent_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          to_email: string;
          template_key: string;
          subject: string;
          body: string;
          payload?: Json;
          status?: Database["public"]["Enums"]["email_outbox_status"];
          error?: string | null;
          attempts?: number;
          dedupe_key: string;
          scheduled_at?: string;
          sent_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["email_outbox"]["Insert"]>;
        Relationships: [];
      };
      booking_series: {
        Row: {
          id: string;
          barbershop_id: string;
          customer_id: string;
          service_id: string;
          staff_id: string;
          kind: Database["public"]["Enums"]["booking_series_kind"];
          weekday: number | null;
          interval_days: number | null;
          local_time: string;
          anchor_starts_at: string;
          active: boolean;
          created_by: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barbershop_id: string;
          customer_id: string;
          service_id: string;
          staff_id: string;
          kind: Database["public"]["Enums"]["booking_series_kind"];
          weekday?: number | null;
          interval_days?: number | null;
          local_time: string;
          anchor_starts_at: string;
          active?: boolean;
          created_by: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["booking_series"]["Insert"]>;
        Relationships: [];
      };
      auth_otp_challenges: {
        Row: {
          id: string;
          user_id: string | null;
          barbershop_id: string;
          channel: Database["public"]["Enums"]["auth_otp_channel"];
          destination: string;
          code_hash: string;
          purpose: Database["public"]["Enums"]["auth_otp_purpose"];
          expires_at: string;
          consumed_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          barbershop_id: string;
          channel: Database["public"]["Enums"]["auth_otp_channel"];
          destination: string;
          code_hash: string;
          purpose: Database["public"]["Enums"]["auth_otp_purpose"];
          expires_at: string;
          consumed_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["auth_otp_challenges"]["Insert"]>;
        Relationships: [];
      };
      google_connections: {
        Row: {
          id: string;
          user_id: string;
          google_email: string | null;
          scopes: string[];
          access_token: string;
          refresh_token: string | null;
          token_expires_at: string | null;
          calendar_sync_enabled: boolean;
          contacts_sync_enabled: boolean;
          last_calendar_sync_at: string | null;
          last_contacts_sync_at: string | null;
          last_error: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          google_email?: string | null;
          scopes?: string[];
          access_token: string;
          refresh_token?: string | null;
          token_expires_at?: string | null;
          calendar_sync_enabled?: boolean;
          contacts_sync_enabled?: boolean;
          last_calendar_sync_at?: string | null;
          last_contacts_sync_at?: string | null;
          last_error?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["google_connections"]["Insert"]>;
        Relationships: [];
      };
      google_calendar_events: {
        Row: {
          id: string;
          user_id: string;
          google_event_id: string;
          calendar_id: string;
          title: string | null;
          description: string | null;
          starts_at: string;
          ends_at: string;
          all_day: boolean;
          html_link: string | null;
          raw: Json;
          synced_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          google_event_id: string;
          calendar_id?: string;
          title?: string | null;
          description?: string | null;
          starts_at: string;
          ends_at: string;
          all_day?: boolean;
          html_link?: string | null;
          raw?: Json;
          synced_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["google_calendar_events"]["Insert"]>;
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      whatsapp_send_dashboard: { Args: Record<string, never>; Returns: Json };
      set_whatsapp_send_pause: {
        Args: { p_scope: string; p_paused: boolean; p_reason: string; p_version?: number };
        Returns: Json;
      };

      platform_set_whatsapp_route: {
        Args: {
          p_shop: string;
          p_staff: string | null;
          p_version: number;
          p_primary_id: string | null;
          p_backup_id: string | null;
          p_mode: string;
          p_enabled: boolean;
          p_returns: boolean;
          p_technical: boolean;
        };
        Returns: Json;
      };
      platform_configure_whatsapp_number: {
        Args: {
          p_id: string;
          p_version: number;
          p_backup_id: string | null;
          p_mode: string;
          p_technical: boolean;
          p_return_enabled: boolean;
          p_keep_legacy?: boolean;
        };
        Returns: Json;
      };
      platform_add_whatsapp_link: {
        Args: {
          p_id: string;
          p_version: number;
          p_shop: string;
          p_staff: string | null;
          p_enabled?: boolean;
        };
        Returns: Json;
      };
      platform_update_whatsapp_link: {
        Args: {
          p_link: string;
          p_version: number;
          p_enabled: boolean;
          p_returns: boolean;
          p_remove?: boolean;
        };
        Returns: Json;
      };
      shop_whatsapp_channel: { Args: { p_shop: string }; Returns: Json };
      shop_update_whatsapp_preferences: {
        Args: {
          p_shop: string;
          p_link: string;
          p_version: number;
          p_enabled: boolean;
          p_booking: boolean;
          p_reminder: boolean;
          p_hours: number;
        };
        Returns: Json;
      };
      care_group_read: { Args: { p_shop: string; p_customer?: string }; Returns: Json };
      care_group_begin: {
        Args: { p_shop: string; p_accept: boolean; p_accounts: string[]; p_phone: string };
        Returns: Json;
      };
      care_group_request: {
        Args: { p_shop: string; p_accept: boolean; p_accounts: string[] };
        Returns: Json;
      };
      care_group_customer_update: {
        Args: { p_group: string; p_version: number; p_action: string; p_values?: Json };
        Returns: Json;
      };
      care_group_admin: { Args: { p_action: string; p_values?: Json }; Returns: Json };
      care_group_invite: { Args: { p_group: string }; Returns: string };
      platform_whatsapp_directory: { Args: Record<string, never>; Returns: Json };
      platform_create_whatsapp_channel: {
        Args: { p_id: string; p_label: string };
        Returns: string;
      };
      platform_assign_whatsapp_channel: {
        Args: {
          p_id: string;
          p_version: number;
          p_shop: string | null;
          p_staff: string | null;
          p_enabled: boolean;
        };
        Returns: Json;
      };
      configure_shop_whatsapp_delivery: {
        Args: {
          p_shop_id: string;
          p_backup_instance: string | null;
          p_mode: string;
          p_reason: string;
          p_return_enabled: boolean;
        };
        Returns: Json;
      };
      get_available_slots: {
        Args: {
          p_shop_id: string;
          p_service_id: string;
          p_date: string;
          p_staff_id?: string | null;
        };
        Returns: { staff_id: string; starts_at: string; ends_at: string }[];
      };
      get_booking_terms: {
        Args: { p_shop_id: string };
        Returns: {
          staff_id: string;
          service_id: string;
          duration_minutes: number;
          price_cents: number;
        }[];
      };
      shop_can_manage_whatsapp: { Args: { p_shop_id: string }; Returns: boolean };
      normalize_br_whatsapp: { Args: { p_raw: string }; Returns: string };
      save_my_whatsapp: {
        Args: { p_raw: string; p_opt_in: boolean };
        Returns: Database["public"]["Tables"]["profiles"]["Row"];
      };
      process_whatsapp_reminders: { Args: Record<string, never>; Returns: number };
      claim_whatsapp_outbox: {
        Args: { p_limit?: number };
        Returns: Database["public"]["Tables"]["whatsapp_outbox"]["Row"][];
      };
      complete_whatsapp_outbox: {
        Args: {
          p_id: string;
          p_ok: boolean;
          p_provider_message_id?: string | null;
          p_error?: string | null;
        };
        Returns: undefined;
      };
      enqueue_whatsapp_message: {
        Args: {
          p_shop_id: string;
          p_to_e164: string;
          p_template_key: string;
          p_body: string;
          p_dedupe_key: string;
          p_payload?: Json;
          p_scheduled_at?: string;
        };
        Returns: string;
      };
      lookup_appointment_by_token: { Args: { p_token: string }; Returns: Json };
      send_client_notice: {
        Args: { p_shop_id: string; p_customer_id: string; p_preset: string };
        Returns: Json;
      };
      get_client_notice_pending: {
        Args: { p_shop_id: string; p_customer_id: string };
        Returns: Json;
      };
      process_pending_client_notices: { Args: Record<string, never>; Returns: number };
      expire_shop_change_requests: { Args: Record<string, never>; Returns: number };
      list_pending_shop_changes: { Args: { p_shop_id: string }; Returns: Json };
      set_favorite_staff: {
        Args: { p_shop_id: string; p_staff_id: string | null };
        Returns: Json;
      };
      pick_available_staff: {
        Args: {
          p_shop_id: string;
          p_service_id: string;
          p_starts_at: string;
          p_ends_at: string;
          p_prefer_staff_id?: string | null;
        };
        Returns: string;
      };
      suggest_partner_catalog: {
        Args: {
          p_shop_id: string;
          p_service_id: string;
          p_price_cents: number;
          p_duration_minutes: number;
          p_display_name?: string | null;
        };
        Returns: Json;
      };
      decide_partner_catalog_suggestion: {
        Args: { p_suggestion_id: string; p_accept: boolean };
        Returns: Json;
      };
      assign_account_manager_shop: {
        Args: {
          p_user_id: string;
          p_shop_id: string;
          p_can_view_dashboard?: boolean;
        };
        Returns: Json;
      };
      unassign_account_manager_shop: {
        Args: { p_user_id: string; p_shop_id: string };
        Returns: undefined;
      };
      create_booking_series: {
        Args: {
          p_shop_id: string;
          p_service_id: string;
          p_staff_id: string;
          p_starts_at: string;
          p_kind: string;
          p_interval_days?: number | null;
        };
        Returns: Json;
      };
      stop_booking_series: { Args: { p_series_id: string }; Returns: undefined };
      extend_booking_series: { Args: Record<string, never>; Returns: number };
      claim_email_outbox: {
        Args: { p_limit?: number };
        Returns: Database["public"]["Tables"]["email_outbox"]["Row"][];
      };
      complete_email_outbox: {
        Args: { p_id: string; p_ok: boolean; p_error?: string | null };
        Returns: undefined;
      };
      get_my_google_connection: {
        Args: Record<string, never>;
        Returns: Json;
      };
      set_google_calendar_push: {
        Args: { p_scope: string };
        Returns: Json;
      };
      join_shop_as_customer: {
        Args: { p_shop_ref: string };
        Returns: Json;
      };
      get_shop_join_preview: {
        Args: { p_shop_ref: string };
        Returns: Json;
      };
      get_public_shop_branding: {
        Args: { p_shop_ref: string };
        Returns: {
          shop_id: string;
          shop_name: string;
          display_name: string | null;
          logo_url: string | null;
          logo_background_color: string | null;
          font_family: string | null;
          custom_font_url: string | null;
          header_font_weight: number | null;
          header_font_style: string | null;
          corner_style: string | null;
          primary_color: string | null;
          accent_color: string | null;
        }[];
      };
      get_public_shop_landing: {
        Args: { p_shop_ref?: string | null; p_host?: string | null };
        Returns: Json;
      };
      landing_config_valid: { Args: { p: Json }; Returns: boolean };
      get_public_shop_branding_v2: {
        Args: { p_shop_ref: string };
        Returns: {
          shop_id: string;
          shop_name: string;
          display_name: string | null;
          logo_url: string | null;
          logo_background_color: string | null;
          font_family: string | null;
          custom_font_url: string | null;
          header_font_weight: number | null;
          header_font_style: string | null;
          corner_style: string | null;
          primary_color: string | null;
          accent_color: string | null;
          login_layout: string | null;
          login_image_url: string | null;
        }[];
      };
      get_partner_wallet: { Args: { p_shop_id: string }; Returns: Json };
      get_partner_clients: { Args: { p_shop_id: string }; Returns: Json };
      get_client_profile: {
        Args: { p_shop_id: string; p_customer_id: string };
        Returns: Json;
      };
      get_customer_rhythm: { Args: { p_shop_id: string }; Returns: Json };
      get_partner_rhythm: { Args: { p_shop_id: string }; Returns: Json };
      get_my_shop_permissions: { Args: { p_shop_id: string }; Returns: Json };
      get_shop_permissions: { Args: { p_shop_id: string }; Returns: Json };
      save_shop_permissions: {
        Args: { p_shop_id: string; p_matrix: Json };
        Returns: Json;
      };
      shop_permission_granted: {
        Args: { p_shop_id: string; p_permission: string };
        Returns: boolean;
      };
      record_customer_survey_response: {
        Args: { p_appointment_id: string; p_question: string; p_answer: string };
        Returns: string;
      };
      get_service_interest_insights: {
        Args: { p_shop_id: string | null; p_from: string; p_to: string };
        Returns: Json;
      };
      cancel_appointment: { Args: { p_id: string; p_reason?: string | null }; Returns: undefined };
      get_appointment_cancellations: { Args: { p_shop_id?: string | null }; Returns: Json };
      export_my_data: { Args: Record<string, never>; Returns: Json };
      list_privacy_requests: { Args: { p_admin: boolean }; Returns: Json };
      request_account_deletion: { Args: Record<string, never>; Returns: string };
      update_privacy_request: { Args: { p_id: string; p_status: string }; Returns: undefined };
      withdraw_appointment_confirmation: { Args: { p_id: string }; Returns: undefined };
      waiting_action: {
        Args: { p_id: string; p_action: string; p_service_id?: string | null };
        Returns: string | null;
      };
      get_waiting_state: { Args: { p_shop_id: string }; Returns: Json };
      get_appointment_attendance: { Args: { p_id: string }; Returns: Json };
      set_shop_loyalty_module: {
        Args: { p_shop_id: string; p_enabled: boolean };
        Returns: undefined;
      };
      get_shop_loyalty_program: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      list_shop_loyalty_customers: {
        Args: { p_shop_id: string; p_search?: string | null; p_limit?: number };
        Returns: {
          user_id: string;
          full_name: string;
          points: number;
          lifetime_points: number;
          updated_at: string;
        }[];
      };
      list_shop_loyalty_redemptions: {
        Args: { p_shop_id: string; p_status?: string | null };
        Returns: {
          id: string;
          user_id: string;
          full_name: string;
          reward_name: string;
          cost_points: number;
          status: string;
          created_at: string;
          expires_at: string;
          resolved_at: string | null;
        }[];
      };
      save_loyalty_program: {
        Args: {
          p_shop_id: string;
          p_mode: string;
          p_points_per_visit: number | null;
          p_welcome_bonus: number | null;
          p_tiers: Json | null;
        };
        Returns: Json;
      };
      save_loyalty_reward: {
        Args: {
          p_shop_id: string;
          p_reward_id: string | null;
          p_name: string;
          p_description: string;
          p_cost_points: number;
          p_active: boolean;
          p_sort_order?: number;
        };
        Returns: string;
      };
      adjust_loyalty_points: {
        Args: { p_shop_id: string; p_user_id: string; p_delta: number; p_reason: string };
        Returns: number;
      };
      request_loyalty_redemption: {
        Args: { p_reward_id: string };
        Returns: string;
      };
      resolve_loyalty_redemption: {
        Args: { p_redemption_id: string; p_action: string };
        Returns: string;
      };
      set_shop_sports_module: {
        Args: { p_shop_id: string; p_enabled: boolean };
        Returns: undefined;
      };
      save_appointment_occurrence: {
        Args: {
          p_id: string;
          p_customer_delay: number | null;
          p_shop_delay: number | null;
          p_no_show: boolean;
        };
        Returns: undefined;
      };
      get_occurrence_insights: {
        Args: { p_shop_id: string | null; p_from: string; p_to: string };
        Returns: Json;
      };
      record_attendance: {
        Args: { p_appointment_id: string; p_stage: string };
        Returns: undefined;
      };
      get_business_insights: {
        Args: { p_shop_id: string | null; p_from: string; p_to: string };
        Returns: Json;
      };
      get_my_privacy: { Args: Record<string, never>; Returns: Json };
      save_my_privacy: {
        Args: { p_analytics: boolean; p_surveys: boolean; p_marketing: boolean };
        Returns: undefined;
      };
      next_customer_survey: { Args: Record<string, never>; Returns: Json };
      answer_customer_survey: {
        Args: { p_id: string; p_answer: string | null };
        Returns: undefined;
      };
      record_customer_usage: {
        Args: { p_id: string; p_shop_id: string; p_event: string };
        Returns: undefined;
      };
      erase_my_optional_data: { Args: Record<string, never>; Returns: undefined };
      delete_my_account: { Args: Record<string, never>; Returns: Json };

      reschedule_own_appointment: {
        Args: {
          p_appointment_id: string;
          p_service_id: string;
          p_staff_id: string;
          p_starts_at: string;
          p_ends_at: string;
        };
        Returns: string;
      };
      get_staff_busy_intervals: {
        Args: { p_staff_id: string; p_starts_at: string; p_ends_at: string };
        Returns: { starts_at: string; ends_at: string }[];
      };
      is_platform_admin: {
        Args: Record<string, never>;
        Returns: boolean;
      };
      has_shop_role: {
        Args: {
          p_shop_id: string;
          p_roles: Database["public"]["Enums"]["app_role"][];
        };
        Returns: boolean;
      };
      get_mercado_pago_connection: {
        Args: { p_shop_id: string; p_receiver_scope?: string; p_staff_id?: string | null };
        Returns: Json;
      };
      begin_mercado_pago_connection: {
        Args: {
          p_shop_id: string;
          p_actor_id: string;
          p_state_hash: string;
          p_verifier_ciphertext: string;
          p_expected_revision: number;
          p_environment: string;
          p_receiver_scope: string;
          p_staff_id: string | null;
          p_connection_id: string;
        };
        Returns: Json;
      };
      consume_mercado_pago_connection: {
        Args: { p_state_hash: string; p_actor_id: string };
        Returns: Json;
      };
      finish_mercado_pago_connection: {
        Args: {
          p_attempt_id: string;
          p_actor_id: string;
          p_collector_id: string;
          p_access_token_ciphertext: string;
          p_refresh_token_ciphertext: string;
          p_token_expires_at: string;
          p_live_mode: boolean;
        };
        Returns: Json;
      };
      disconnect_mercado_pago_connection: {
        Args: {
          p_shop_id: string;
          p_actor_id: string;
          p_expected_revision: number;
          p_receiver_scope?: string;
          p_staff_id?: string | null;
        };
        Returns: Json;
      };
      get_weekly_break_governance: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      request_weekly_break_change: {
        Args: { p_shop_id: string; p_action: string; p_payload: Json };
        Returns: Json;
      };
      request_shop_change: {
        Args: { p_shop_id: string; p_kind: string; p_payload: Json };
        Returns: Json;
      };
      decide_shop_change: {
        Args: { p_request_id: string; p_approve: boolean; p_note?: string | null };
        Returns: Json;
      };
      cancel_shop_change: {
        Args: { p_request_id: string };
        Returns: undefined;
      };
      get_team_schedule: {
        Args: { p_shop_id: string; p_from: string; p_to: string };
        Returns: Json;
      };
      get_shop_access_context: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      list_shop_blocks: {
        Args: { p_shop_id: string; p_from?: string };
        Returns: {
          id: string;
          barbershop_id: string;
          staff_id: string | null;
          starts_at: string;
          ends_at: string;
          reason: string | null;
          created_at: string;
          staff_display_name: string | null;
          rule_id?: string | null;
        }[];
      };
      list_platform_shop_owners: {
        Args: Record<PropertyKey, never>;
        Returns: { barbershop_id: string; user_id: string }[];
      };
      get_professional_insights: {
        Args: { p_shop_id: string; p_from: string; p_to: string };
        Returns: Json;
      };
      resolve_direct_booking_staff: {
        Args: { p_shop_slug: string; p_staff_slug: string };
        Returns: Json;
      };
      resolve_shop_by_slug: {
        Args: { p_shop_ref: string };
        Returns: string;
      };
      list_shop_slug_redirects: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      list_staff_slug_redirects: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      delete_shop_slug_redirect: {
        Args: { p_redirect_id: string };
        Returns: undefined;
      };
      delete_staff_slug_redirect: {
        Args: { p_redirect_id: string };
        Returns: undefined;
      };
      request_shop_departure: {
        Args: {
          p_shop_id: string;
          p_mode: "take" | "forfeit";
          p_dest_shop_id?: string | null;
        };
        Returns: Json;
      };
      approve_portfolio_release: {
        Args: { p_request_id: string; p_note?: string | null };
        Returns: Json;
      };
      reject_portfolio_release: {
        Args: { p_request_id: string; p_note?: string | null };
        Returns: Json;
      };
      complete_shop_departure: {
        Args: { p_request_id: string };
        Returns: undefined;
      };
      list_shop_departure_requests: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      cancel_shop_departure: {
        Args: { p_request_id: string };
        Returns: Json;
      };
      list_departure_appointments: {
        Args: { p_shop_id: string; p_staff_id?: string | null };
        Returns: Json;
      };
      reassign_appointment_staff: {
        Args: { p_appointment_id: string; p_staff_id: string };
        Returns: Json;
      };
      register_my_barbershop: {
        Args: {
          p_request_id: string;
          p_name: string;
          p_timezone: string;
          p_society_intent: string;
          p_terms_accepted: boolean;
          p_terms_version: string;
          p_privacy_version: string;
          p_dpa_version: string;
        };
        Returns: Json;
      };
      create_own_barbershop: {
        Args: { p_name: string };
        Returns: Json;
      };
      resolve_shop_by_host: {
        Args: { p_host: string };
        Returns: Json;
      };
      get_shop_domain_settings: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      shop_has_booking_slug: {
        Args: { p_shop_id: string; p_booking_slug: string };
        Returns: boolean;
      };
      set_shop_custom_domain: {
        Args: { p_shop_id: string; p_domain: string };
        Returns: Json;
      };
      clear_shop_custom_domain: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      mark_shop_domain_status: {
        Args: {
          p_shop_id: string;
          p_status: "none" | "pending_dns" | "active" | "error";
          p_error?: string | null;
        };
        Returns: Json;
      };
      get_public_shop_branding_by_host: {
        Args: { p_host: string };
        Returns: Json;
      };
      list_active_custom_domains: {
        Args: Record<string, never>;
        Returns: Json;
      };
      oauth_relay_failure_put: {
        Args: { p_id: string };
        Returns: boolean;
      };
      oauth_relay_failure_take: {
        Args: { p_id: string };
        Returns: boolean;
      };
      oauth_relay_put: {
        Args: { p_id: string; p_code: string };
        Returns: boolean;
      };
      oauth_relay_take: {
        Args: { p_id: string };
        Returns: string | null;
      };
      find_shop_client: {
        Args: { p_shop_id: string; p_whatsapp: string };
        Returns: Json;
      };
      get_team_slots: {
        Args: { p_shop_id: string; p_staff_id: string; p_service_id: string; p_date: string };
        Returns: { starts_at: string; ends_at: string }[];
      };
      book_for_client: {
        Args: {
          p_shop_id: string;
          p_staff_id: string;
          p_service_id: string;
          p_starts_at: string;
          p_customer_id?: string | null;
          p_shop_client_id?: string | null;
          p_name?: string | null;
          p_whatsapp?: string | null;
          p_nickname?: string | null;
          p_notify?: boolean | null;
        };
        Returns: Json;
      };
      set_client_nickname: {
        Args: {
          p_shop_id: string;
          p_customer_id: string | null;
          p_shop_client_id: string | null;
          p_nickname: string;
        };
        Returns: string | null;
      };
      update_shop_client: {
        Args: {
          p_shop_id: string;
          p_shop_client_id: string;
          p_full_name?: string | null;
          p_whatsapp?: string | null;
          p_notify?: boolean | null;
        };
        Returns: Json;
      };
      get_shop_client: {
        Args: { p_shop_id: string; p_shop_client_id: string };
        Returns: Json;
      };
      create_direct_appointment: {
        Args: {
          p_shop_slug: string;
          p_staff_slug: string;
          p_service_id: string;
          p_starts_at: string;
          p_ends_at: string;
        };
        Returns: string;
      };
      platform_add_shop_member: {
        Args: {
          p_shop_id: string;
          p_user_id: string;
          p_role: Database["public"]["Enums"]["shop_member_role"];
          p_ownership_percent?: number | null;
          p_display_name?: string | null;
          p_staff_id?: string | null;
        };
        Returns: string;
      };
      shop_add_member: {
        Args: {
          p_shop_id: string;
          p_user_id: string;
          p_role: Database["public"]["Enums"]["shop_member_role"];
          p_ownership_percent?: number | null;
          p_display_name?: string | null;
          p_staff_id?: string | null;
        };
        Returns: Json;
      };
      mark_shop_welcome_seen: { Args: { p_shop_id: string }; Returns: boolean };
      get_my_pending_shop_invites: { Args: Record<string, never>; Returns: Json };
      get_shop_setup_guide: { Args: { p_shop_id: string }; Returns: Json };
      save_shop_setup_guide: { Args: { p_shop_id: string; p_patch: Json }; Returns: Json };
      platform_user_emails: {
        Args: { p_user_ids: string[] };
        Returns: { user_id: string; email: string | null }[];
      };
      shop_update_member: {
        Args: {
          p_shop_id: string;
          p_member_id: string;
          p_role?: Database["public"]["Enums"]["shop_member_role"] | null;
          p_ownership_percent?: number | null;
          p_active?: boolean | null;
        };
        Returns: Json;
      };
      transfer_shop_founder: {
        Args: {
          p_shop_id: string;
          p_new_founder_user_id: string;
        };
        Returns: Json;
      };
      list_shop_team_members: {
        Args: { p_shop_id: string };
        Returns: Json;
      };
      can_apply_protected_change: {
        Args: { p_shop_id: string };
        Returns: boolean;
      };
      is_account_manager_of: {
        Args: { p_shop_id: string };
        Returns: boolean;
      };
    };
    Enums: {
      app_role: "customer" | "shop_admin" | "platform_admin" | "account_manager";
      barbershop_status: "active" | "suspended";
      appointment_status:
        | "pending"
        | "confirmed"
        | "cancelled"
        | "completed"
        | "reschedule_requested";
      shop_member_role: "owner" | "partner" | "associate" | "employee";
      shop_change_status: "pending" | "approved" | "rejected" | "cancelled" | "expired";
      whatsapp_channel_status: "disconnected" | "qr" | "connecting" | "open";
      whatsapp_outbox_status: "pending" | "sending" | "sent" | "failed";
      email_outbox_status: "pending" | "sending" | "sent" | "failed";
      booking_series_kind: "weekday" | "interval_days";
      booking_series_exception_reason:
        | "skipped_busy"
        | "cancelled"
        | "rescheduled_out"
        | "series_stopped";
      auth_otp_channel: "whatsapp" | "email";
      auth_otp_purpose: "login" | "recovery";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      app_role: ["customer", "shop_admin", "platform_admin", "account_manager"] as const,
      barbershop_status: ["active", "suspended"] as const,
      appointment_status: [
        "pending",
        "confirmed",
        "cancelled",
        "completed",
        "reschedule_requested",
      ] as const,
      shop_member_role: ["owner", "partner", "associate", "employee"] as const,
      shop_change_status: ["pending", "approved", "rejected", "cancelled"] as const,
      email_outbox_status: ["pending", "sending", "sent", "failed"] as const,
      booking_series_kind: ["weekday", "interval_days"] as const,
      booking_series_exception_reason: [
        "skipped_busy",
        "cancelled",
        "rescheduled_out",
        "series_stopped",
      ] as const,
    },
  },
} as const;
