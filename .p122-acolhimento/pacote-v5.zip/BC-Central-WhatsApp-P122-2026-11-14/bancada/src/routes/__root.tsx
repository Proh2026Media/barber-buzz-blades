import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { NotFoundPage } from "../components/NotFoundPage";

import appCss from "../styles.css?url";
import deviceCss from "../dispositivos.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { themeBootstrapScript } from "../lib/theme";
import { deviceBootstrapScript } from "../lib/device";
import { DEFAULT_LOCALE, localeFromTag, localeBootstrapScript } from "../lib/i18n/locale";
import { useI18n } from "../lib/i18n";
import { PushAccountGuard } from "@/features/notifications/PushAccountGuard";
import { PwaRegister } from "../lib/pwa";
import { VisibleViewport } from "../lib/visible-viewport";
import { PwaInstallBanner, PwaInstallProvider } from "../components/pwa-install-banner";
import { Toaster } from "../components/ui/sonner";

import { loadLocale } from "../lib/i18n/translate";

const APP_NAME = "Barba & Cabelo";
const APP_DESCRIPTION =
  "Agendamento, fidelidade e gestão para barbearias: reserve seu horário, acompanhe pontos e organize a agenda da equipe.";

// Página 404 compartilhada com as rotas só do navegador (ver NotFoundPage).
const NotFoundComponent = NotFoundPage;

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  const { t } = useI18n();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          {t("app.error.title")}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">{t("app.error.body")}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex min-h-11 items-center justify-center rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {t("app.error.retry")}
          </button>
          <a
            href="/"
            className="inline-flex min-h-11 items-center justify-center rounded-xl border border-input bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-accent"
          >
            {t("app.common.backHome")}
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  beforeLoad: async ({ location }) => {
    const lang = new URLSearchParams(location.searchStr).get("lang");
    await loadLocale(localeFromTag(lang) ?? DEFAULT_LOCALE);
  },
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "description", content: APP_DESCRIPTION },
      { name: "application-name", content: APP_NAME },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "apple-mobile-web-app-title", content: APP_NAME },
      { name: "mobile-web-app-capable", content: "yes" },
      { name: "format-detection", content: "telephone=no" },
      { name: "color-scheme", content: "light dark" },
      // HeadContent dedupes meta by name, so a single browser-chrome color is declared.
      { name: "theme-color", content: "#20211f" },
      { property: "og:title", content: APP_NAME },
      { property: "og:description", content: APP_DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "pt_BR" },
      { name: "twitter:card", content: "summary" },
    ],
    // Aplica o tema salvo, o idioma e a faixa de dispositivo antes da primeira pintura
    // (em sincronia com `useTheme`, `useI18n` e `useDevice`).
    scripts: [
      { children: themeBootstrapScript },
      { children: localeBootstrapScript },
      { children: deviceBootstrapScript },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      // CSS por dispositivo (src/dispositivos.css → src/styles/*.css) depois do styles.css:
      // vence em igualdade de especificidade.
      { rel: "stylesheet", href: deviceCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", href: "/icons/icon-192.png", type: "image/png" },
      { rel: "apple-touch-icon", href: "/icons/icon-180.png" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <VisibleViewport />
      <PwaRegister />
      <PushAccountGuard />
      <PwaInstallProvider>
        <PwaInstallBanner fallback />
        {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
        <Outlet />
      </PwaInstallProvider>
      <Toaster />
    </QueryClientProvider>
  );
}
