import { sendGroupLogin } from "./whatsapp-group-login.ts";
import { sendWhatsapp } from "./whatsapp-send.ts";

/** Transporte da Evolution; envios somente pela autorização comum. */

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function evolutionConfig() {
  const url = (
    Deno.env.get("EVOLUTION_API_URL") ?? "https://evolutionapi.contheiner.digital"
  ).replace(/\/$/, "");
  const apiKey = Deno.env.get("EVOLUTION_API_KEY") ?? Deno.env.get("AUTHENTICATION_API_KEY");
  if (!apiKey) throw new Error("Missing EVOLUTION_API_KEY");
  return { url, apiKey };
}

async function evolutionRequest(path: string, init: RequestInit = {}) {
  const { url, apiKey } = evolutionConfig();
  const response = await fetch(`${url}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      apikey: apiKey,
      ...(init.headers ?? {}),
    },
  });
  const text = await response.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }
  if (!response.ok) {
    let message = text.slice(0, 300) || response.statusText;
    if (typeof data === "object" && data && "message" in data) {
      const raw = (data as { message: unknown }).message;
      message = Array.isArray(raw) ? raw.map(String).join(" ") : String(raw);
    } else if (typeof data === "object" && data && "response" in data) {
      const nested = (data as { response?: { message?: unknown } }).response?.message;
      if (nested != null) {
        message = Array.isArray(nested) ? nested.map(String).join(" ") : String(nested);
      }
    }
    throw new Error(message);
  }
  return data;
}

export async function evolutionFetch(path: string, init: RequestInit = {}) {
  // O cliente de administração só administra instâncias. Não aceita outros caminhos.
  if (
    (!/^\/instance\/(create|connect|connectionState|fetchInstances|logout|delete)(?:\/|\?|$)/.test(
      path,
    ) &&
      !(path.startsWith("/group/findGroupInfos/") && (!init.method || init.method === "GET"))) ||
    path.includes("..") ||
    /%2e|%2f/i.test(path)
  )
    throw new Error("WA_OUTBOUND_REQUIRED");
  return evolutionRequest(path, init);
}

export function sendAuthorizedWhatsapp(
  ...args: [Parameters<typeof sendWhatsapp>[0], Parameters<typeof sendWhatsapp>[1]]
) {
  return sendWhatsapp(...args, evolutionGroupTransport, groupCycleEnabled());
}

export function instanceNameForShop(shopId: string, slug?: string | null) {
  const base = (slug ?? shopId)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
  const suffix = shopId.replace(/-/g, "").slice(0, 8);
  return `shop-${base || "barber"}-${suffix}`.slice(0, 63);
}

export function digitsOnlyPhone(e164: string) {
  return e164.replace(/\D/g, "");
}

/** Administração de grupos separada do transporte de mensagens; somente endpoints protegidos de envio. */
export function evolutionGroupTransport(path: string, init: RequestInit = {}) {
  const match = /^\/group\/([A-Za-z]+)\/[A-Za-z0-9_-]{1,100}(?:\?[^#]*)?$/.exec(path);
  const get = [
    "bcCapabilities",
    "bcInspect",
    "bcCreateStatus",
    "joinRequests",
    "bcInvite",
    "bcCycle",
    "bcOperation",
    "bcCreationStatus",
  ];
  const post = [
    "bcSendNotice",
    "bcSendCode",
    "bcCreate",
    "bcRecoverCycle",
    "bcPrepare",
    "bcWelcome",
    "bcDescription",
    "bcBrand",
    "bcPinNotice",
    "bcClose",
    "bcAdoptClosing",
    "bcAuthorizePlatform",
    "bcSubject",
    "bcSetting",
    "updateMemberAddMode",
    "updateJoinApprovalMode",
    "joinRequests",
    "bcMember",
    "bcRevoke",
  ];
  if (
    !match ||
    !(init.method === "POST" ? post : !init.method || init.method === "GET" ? get : []).includes(
      match[1],
    )
  ) {
    throw new Error("GROUP_ROUTE_FORBIDDEN");
  }
  return evolutionRequest(path, {
    ...init,
    headers: { ...init.headers, "x-bc-group-key": Deno.env.get("WHATSAPP_GROUP_API_SECRET") ?? "" },
  });
}

/** Não liberar por variável de ambiente antes do piloto de composição/isolamento. */
export function sendAuthorizedGroupLogin(
  ...args: [Parameters<typeof sendGroupLogin>[0], Parameters<typeof sendGroupLogin>[1]]
) {
  return sendGroupLogin(...args, evolutionGroupTransport, groupCycleEnabled());
}

export function groupPilotEnabled() {
  return (
    Deno.env.get("WHATSAPP_GROUP_PILOT_ENABLED") === "true" &&
    (Deno.env.get("WHATSAPP_GROUP_API_SECRET") ?? "").length >= 32
  );
}

/** Contrato novo não herda habilitação de um piloto antigo. */
export function groupCycleEnabled() {
  return groupPilotEnabled() && Deno.env.get("WHATSAPP_GROUP_CYCLE_ENABLED") === "true";
}
